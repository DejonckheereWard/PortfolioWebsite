#include "stdafx.h"
#include "MainMenu.h"
#include <Materials/Shadow/DiffuseMaterial_Shadow.h>

#include "Prefabs/UI/Button.h"
#include "Prefabs/UI/Cursor.h"

#include "Scenes/Exam/MainScene.h"

MainMenu::MainMenu()
	:GameScene{ L"MainMenu" }
{}

MainMenu::~MainMenu()
{}

void MainMenu::Initialize()
{
	m_SceneContext.settings.enableOnGUI = false;
	m_SceneContext.settings.drawGrid = false;
	m_SceneContext.settings.drawPhysXDebug = false;
	m_SceneContext.settings.showInfoOverlay = false;
	m_SceneContext.settings.drawUserDebug = false;

	// Load fonts
	// *********
	m_pPortalFont = ContentManager::Load<SpriteFont>(L"SpriteFonts/Portal.fnt");

	//Camera
	const auto pCamera = AddChild(new FixedCamera());
	auto m_pCameraComponent = pCamera->GetComponent<CameraComponent>();
	m_pCameraComponent->SetActive(true);

	const auto pGroundMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pGroundMaterial->SetDiffuseTexture(L"Textures/world/concrete_modular_floor4.png");


	// Background
	// **********
	m_pBackground = new GameObject();
	m_pBackground->AddComponent(new SpriteComponent(L"Textures/UI/Background.jpg", {}, DirectX::XMFLOAT4(1, 1, 1, 1.f)));
	m_pBackground->GetTransform()->Translate(XMFLOAT3{0, 0, 0.9f});
	AddChild(m_pBackground);
	

	// Buttons
	// *******	
	// Play button
	Button* pButton = new Button(L"Textures/UI/PlayButton.png", L"Textures/UI/PlayButtonSelected.png");
	pButton->GetTransform()->Translate( 167, 244, 0.f );
	pButton->SetOnClick([this]()
	{
		PauseSounds();
		SceneManager::Get()->RemoveGameScene(SceneManager::Get()->GetGameScene(L"MainScene"), true);
		SceneManager::Get()->AddGameScene(new MainScene());
		SceneManager::Get()->SetActiveGameScene(L"MainScene");


	});
	m_Buttons.emplace_back(pButton);
	AddChild(pButton);

	// Quit button
	pButton = new Button(L"Textures/UI/QuitButton.png", L"Textures/UI/QuitButtonSelected.png");
	pButton->GetTransform()->Translate(167, 300, 0.f);
	pButton->SetOnClick([]()
	{
		OverlordGame::Quit();
	});
	m_Buttons.emplace_back(pButton);
	AddChild(pButton);

	// Cursor
	// ******
	m_pCursor = new Cursor();
	m_pCursor->GetTransform()->Translate(XMFLOAT3{ 0, 0, 0.8f });
	AddChild(m_pCursor);

	// Load music
	auto result = SoundManager::Get()->GetSystem()->createStream("Resources/Audio/MenuMusic.mp3", FMOD_LOOP_NORMAL, 0, &m_pBackgroundMusic);
	SoundManager::CheckResult(result);
}

void MainMenu::PostInitialize()
{
	// Scale the texture to fill the screen
	const XMFLOAT2& textureSize = m_pBackground->GetComponent<SpriteComponent>()->GetDimensions();
	const float heightScale{ m_SceneContext.windowHeight / textureSize.y };
	const float widthScale{ m_SceneContext.windowWidth / textureSize.x };

	m_pBackground->GetTransform()->Scale(widthScale, heightScale, 1.0f);

	// Start sound
	SoundManager::Get()->GetSystem()->getChannel(0, &m_pBackgroundMusicChannel);
	SoundManager::Get()->GetSystem()->playSound(m_pBackgroundMusic, 0, false, &m_pBackgroundMusicChannel);
	m_pBackgroundMusicChannel->setVolume(0.3f);
}

void MainMenu::Update()
{

	// Get mouse position
	auto mousePos = GetSceneContext().pInput->GetMousePosition();


	// Is mouse button pressed
	bool isPressed{ InputManager::IsMouseButton(InputState::pressed, VK_LBUTTON) };

	// Update buttons
	for(auto pButton : m_Buttons)
	{
		pButton->UpdateState(XMFLOAT2(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)), isPressed);
	}

	m_pCursor->UpdateState(XMFLOAT2(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)));
}

void MainMenu::Draw()
{
}

void MainMenu::OnGUI()
{
}

void MainMenu::OnSceneActivated()
{
	ResumeSounds();
}

void MainMenu::OnSceneDeactivated()
{
	PauseSounds();
}

void MainMenu::PauseSounds()
{
	m_pBackgroundMusicChannel->setPaused(true);
}


void MainMenu::ResumeSounds()
{
	m_pBackgroundMusicChannel->setPosition(0, FMOD_TIMEUNIT_MS);
	m_pBackgroundMusicChannel->setPaused(false);
}
