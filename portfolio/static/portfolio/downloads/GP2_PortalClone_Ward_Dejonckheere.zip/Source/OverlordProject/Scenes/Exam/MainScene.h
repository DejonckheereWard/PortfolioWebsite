#pragma once
class MainCharacter;
class HUD;
class PauseMenu;

class MainScene : public GameScene
{
public:
	MainScene() :GameScene(L"MainScene") {}
	~MainScene() override;
	MainScene(const MainScene& other) = delete;
	MainScene(MainScene&& other) noexcept = delete;
	MainScene& operator=(const MainScene& other) = delete;
	MainScene& operator=(MainScene&& other) noexcept = delete;

protected:
	void Initialize() override;
	void PostInitialize() override;
	void Update() override;
	void OnGUI() override;

private:
	enum InputIds
	{
		CharacterMoveLeft,
		CharacterMoveRight,
		CharacterMoveForward,
		CharacterMoveBackward,
		CharacterJump,
		OpenPauseMenu,
		GunShootRed,
		GunShootBlue,
		ClearPortals
	};

	FMOD::Channel* m_pBackgroundMusicChannel{ nullptr };
	FMOD::Sound* m_pBackgroundMusic{ nullptr };

	MainCharacter* m_pCharacter{};
	class PostChromatic* m_pPostChromatic{};

	PauseMenu* m_pPauseMenu{};

	HUD* m_pHud{};

	void PauseMusic();
	void ResumeMusic();

	void CreateLevel();
	void InitInputs();
	void InitCharacter();

	void onWinCondition(GameObject* pTrigger, GameObject* pOther, PxTriggerAction action);
};

