#include "stdafx.h"
#include "SpikyScene.h"
#include "Materials/SpikyMaterial.h"

SpikyScene::SpikyScene():
	GameScene(L"SpikyScene")
{}

void SpikyScene::Initialize()
{	
	// SETTINGS
	m_SceneContext.settings.enableOnGUI = true;
	m_SceneContext.settings.drawGrid = false;

	m_pSpikyMaterial = MaterialManager::Get()->CreateMaterial<SpikyMaterial>();

	m_pSpikySphere = new GameObject();
	m_pSpikySphere->AddComponent(new ModelComponent(L"Meshes/OctaSphere.ovm"))->SetMaterial(m_pSpikyMaterial);
	m_pSpikySphere->GetTransform()->Scale(15.0f);
	AddChild(m_pSpikySphere);
};

void SpikyScene::Update()
{
	// Rotate sphere 20 degrees per second
	m_pSpikySphere->GetTransform()->Rotate(0, 20.0f * m_SceneContext.pGameTime->GetTotal(), 0);
}

void SpikyScene::Draw()
{
}

void SpikyScene::OnGUI()
{
	m_pSpikyMaterial->DrawImGui();
}

