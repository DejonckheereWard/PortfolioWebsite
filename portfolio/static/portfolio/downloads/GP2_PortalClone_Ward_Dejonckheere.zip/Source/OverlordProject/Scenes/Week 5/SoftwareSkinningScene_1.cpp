#include "stdafx.h"
#include "SoftwareSkinningScene_1.h"
#include "Materials/ColorMaterial.h"
#include "Prefabs/BoneObject.h"
#include "imgui_internal.h"


SoftwareSkinningScene_1::SoftwareSkinningScene_1():
	GameScene(L"SoftwareSkinningScene_1")
{}

void SoftwareSkinningScene_1::Initialize()
{
	m_SceneContext.settings.enableOnGUI = true;
	ColorMaterial* pMaterial = MaterialManager::Get()->CreateMaterial<ColorMaterial>();
	GameObject* pRoot{ new GameObject() };
	m_pBone0 = new BoneObject(pMaterial, 15.0f);
	pRoot->AddChild(m_pBone0);

	m_pBone1 = new BoneObject(pMaterial, 15.0f);
	m_pBone0->AddBone(m_pBone1);

	AddChild(pRoot);
	
}

void SoftwareSkinningScene_1::Update()
{	
	// Disable rotation if toggled off
	if(!m_AutoRotation)
		return;

	// Invert rotation direction if bone is at max rotation
	if(m_BoneRotation > 45.0f)
		m_RotationSign = -1.0f;
	else if(m_BoneRotation < -45.0f)
		m_RotationSign = 1.0f;

	// Apply rotation
	m_BoneRotation += m_RotationSign * 45.0f * m_SceneContext.pGameTime->GetElapsed();
	m_pBone0->GetTransform()->Rotate(0.0f, 0.0f, m_BoneRotation);
	m_pBone1->GetTransform()->Rotate(0.0f, 0.0f, -m_BoneRotation * 2.0f);

	m_Bone0Rotation.x = XMConvertToDegrees(m_pBone0->GetTransform()->GetRotation().x);
	m_Bone0Rotation.y = XMConvertToDegrees(m_pBone0->GetTransform()->GetRotation().y);
	m_Bone0Rotation.z = XMConvertToDegrees(m_pBone0->GetTransform()->GetRotation().z);

	m_Bone1Rotation.x = XMConvertToDegrees(m_pBone1->GetTransform()->GetRotation().x);
	m_Bone1Rotation.y = XMConvertToDegrees(m_pBone1->GetTransform()->GetRotation().y);
	m_Bone1Rotation.z = XMConvertToDegrees(m_pBone1->GetTransform()->GetRotation().z);
}


void SoftwareSkinningScene_1::OnGUI()
{

	ImGui::Begin("Software Skinning Scene 1");
	ImGui::Checkbox("Auto Rotation", &m_AutoRotation);

	if(m_AutoRotation)
	{
		// Disable and grey out
		ImGui::PushItemFlag(ImGuiItemFlags_Disabled, true);
		ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * 0.5f);
	}

	if(ImGui::DragFloat3("Bone 0 - ROT", &m_Bone0Rotation.x))
		m_pBone0->GetTransform()->Rotate(m_Bone0Rotation.x, m_Bone0Rotation.y, m_Bone0Rotation.z);
	
	if(ImGui::DragFloat3("Bone 1 - ROT", &m_Bone1Rotation.x))
		m_pBone1->GetTransform()->Rotate(m_Bone1Rotation.x, m_Bone1Rotation.y, m_Bone1Rotation.z);

	if(m_AutoRotation)
	{
		// Pop disable and grey flags
		ImGui::PopItemFlag();
		ImGui::PopStyleVar();
	}

	ImGui::End();


}

