#pragma once
class PongScene final: public GameScene
{
public:
	PongScene();
	~PongScene() override = default;

	PongScene(const PongScene& other) = delete;
	PongScene(PongScene&& other) noexcept = delete;
	PongScene& operator=(const PongScene& other) = delete;
	PongScene& operator=(PongScene&& other) noexcept = delete;

protected:
	void Initialize() override;
	void Update() override;
	//void Draw() override;
	//void OnGUI() override;
	void InitBall(PxMaterial* physxMaterial=nullptr);
	void ResetBall();

	void onTrigger(GameObject* pTrigger, GameObject* pOther, PxTriggerAction action);
	void ResetScene();

private:
	GameObject* m_pLeftPaddle{};
	GameObject* m_pRightPaddle{};
	GameObject* m_pBall{};
	
	GameObject* m_pLeftTrigger{};
	GameObject* m_pRightTrigger{};

	bool m_IsLeftTriggered{};
	bool m_IsRightTriggered{};

	FixedCamera* m_pFixedCamera{};

};

