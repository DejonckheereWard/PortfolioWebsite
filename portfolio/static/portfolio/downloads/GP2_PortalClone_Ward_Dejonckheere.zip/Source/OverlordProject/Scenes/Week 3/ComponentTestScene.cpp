#include "stdafx.h"
#include "ComponentTestScene.h"
#include "Prefabs/SpherePrefab.h"

void ComponentTestScene::Initialize()
{
	// PhysX
	auto& physx{ PxGetPhysics() };
	auto pBouncyMaterial{ physx.createMaterial(.5f, .5f, 1.f) };

	// Ground Plane
	GameSceneExt::CreatePhysXGroundPlane(*this, pBouncyMaterial);  // Can also use a default physics material


	// Red Sphere (Grooup 0) & Ignore 1 & 2
	auto pSphereRed = new SpherePrefab(1, 10, XMFLOAT4{ Colors::Red });
	AddChild(pSphereRed);

	pSphereRed->GetTransform()->Translate(0, 30.0f, 0);
	auto pRigidBody{ pSphereRed->AddComponent(new RigidBodyComponent(false)) }; // Dynamic by default
	pRigidBody->AddCollider(PxSphereGeometry{ 1.0f }, *pBouncyMaterial);
	pRigidBody->SetCollisionGroup(CollisionGroup::Group0);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransX, false);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransZ, false);
	//pRigidBody->SetCollisionIgnoreGroups(CollisionGroup::Group1 | CollisionGroup::Group2);

	// Green Sphere (Group 1)
	auto pSphereGreen = new SpherePrefab(1, 10, XMFLOAT4{ Colors::Green });
	AddChild(pSphereGreen);

	pSphereGreen->GetTransform()->Translate(0, 60.0f, 0);
	pRigidBody = pSphereGreen->AddComponent(new RigidBodyComponent(false)); // Dynamic by default
	pRigidBody->AddCollider(PxSphereGeometry{ 1.0f }, *pBouncyMaterial);
	pRigidBody->SetCollisionGroup(CollisionGroup::Group1);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransX, false);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransZ, false);
	pRigidBody->SetDensity(50.0f);


	// Blue Sphere (Group 2)
	auto pSphereBlue = new SpherePrefab(1, 10, XMFLOAT4{ Colors::Blue });
	AddChild(pSphereBlue);

	pSphereBlue->GetTransform()->Translate(0, 90.0f, 0);
	pRigidBody = pSphereBlue->AddComponent(new RigidBodyComponent(false)); // Dynamic by default
	pRigidBody->AddCollider(PxSphereGeometry{ 1.0f }, *pBouncyMaterial);
	pRigidBody->SetCollisionGroup(CollisionGroup::Group1);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransX, false);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransZ, false);
}
