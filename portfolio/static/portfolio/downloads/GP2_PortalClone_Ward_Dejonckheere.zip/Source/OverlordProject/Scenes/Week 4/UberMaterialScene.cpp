#include "stdafx.h"
#include "UberMaterialScene.h"
#include "Prefabs/SpherePrefab.h"
#include "Materials/UberMaterial.h"

UberMaterialScene::UberMaterialScene():
	GameScene(L"UberMaterialScene")
{}

void UberMaterialScene::Initialize()
{
	// SETTINGS
	m_SceneContext.settings.enableOnGUI = true;
	m_SceneContext.settings.drawGrid = false;


	m_pUberMaterial = MaterialManager::Get()->CreateMaterial<UberMaterial>();

	m_pMaterialSphere = new GameObject();  // Init object
	m_pMaterialSphere->AddComponent(new ModelComponent(L"Meshes/Sphere.ovm"))->SetMaterial(m_pUberMaterial);

	m_pMaterialSphere->GetTransform()->Scale(15.0f);

	AddChild(m_pMaterialSphere);
}

void UberMaterialScene::Update()
{
	m_pMaterialSphere->GetTransform()->Rotate(0, 20.0f * m_SceneContext.pGameTime->GetTotal(), 0);
}

void UberMaterialScene::Draw()
{
}

void UberMaterialScene::OnGUI()
{
	m_pUberMaterial->DrawImGui();
}

