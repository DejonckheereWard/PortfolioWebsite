#include "stdafx.h"
#include "ModelTestScene.h"
#include "Managers/MaterialManager.h"
#include "Materials/DiffuseMaterial.h"

ModelTestScene::ModelTestScene():
	GameScene(L"ModelTestScene")
{}

void ModelTestScene::Initialize()
{	
	// Create physx material
	auto& physx{ PxGetPhysics() };
	auto pPhysicsMaterial{ physx.createMaterial(.5f, .5f, 0.1f) };

	// Create physx ground plane
	GameSceneExt::CreatePhysXGroundPlane(*this, pPhysicsMaterial);

	// Create an instance of ColorMaterial and add it to the material manager
	auto* pChairMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial>();
	pChairMaterial->SetDiffuseTexture(L"Textures/Chair_Dark.dds");
	
	m_pChair = new GameObject();  // Init object
	m_pChair->AddComponent(new ModelComponent(L"Meshes/Chair.ovm"))->SetMaterial(pChairMaterial);

	auto pRigidBody = m_pChair->AddComponent(new RigidBodyComponent());
	auto pChairConvexCollider = ContentManager::Load<PxConvexMesh>(L"Meshes/Chair.ovpc");
	pRigidBody->AddCollider(PxConvexMeshGeometry(pChairConvexCollider), *pPhysicsMaterial);

	m_pChair->GetTransform()->Translate(0, 0.1f, 0);  // Translate slightly up to prevent sim instabilities

	AddChild(m_pChair);
};


void ModelTestScene::Update()
{

}