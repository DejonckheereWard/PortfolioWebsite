#include "stdafx.h"
#include "MainScene.h"

#include "Prefabs/Game/MainCharacter.h"
#include "Prefabs/Game/PortalBullet.h"
#include "Prefabs/SpherePrefab.h"
#include "Prefabs/CubePrefab.h"

#include "Prefabs/UI/HUD.h"
#include "Prefabs/UI/PauseMenu.h"

#include "Materials/ColorMaterial.h"

#include "Materials/Post/PostChromatic.h"
#include "Materials/Shadow/DiffuseMaterial_Shadow.h"
#include "Materials/Shadow/DiffuseMaterial_Shadow_Skinned.h"
#include <Materials/DiffuseMaterial.h>

MainScene::~MainScene()
{
	Portal::ClearPortals();
}

void MainScene::Initialize()
{
	m_SceneContext.settings.enableOnGUI = false;
	m_SceneContext.settings.drawGrid = false;
	m_SceneContext.settings.drawPhysXDebug = false;
	m_SceneContext.settings.showInfoOverlay = false;
	m_SceneContext.settings.drawUserDebug = false;

	//const auto pDefaultMaterial = PxGetPhysics().createMaterial(0.5f, 0.5f, 0.5f);

	// Set up bullet manager

	//Character
	InitCharacter();

	// Level
	CreateLevel();

	// Create HUD
	m_pHud = new HUD();
	AddChild(m_pHud);

	// Create pause menu
	m_pPauseMenu = new PauseMenu();
	m_pPauseMenu->GetTransform()->Translate(0.f, 0.f, 0.8f);
	AddChild(m_pPauseMenu);

	// Input
	InitInputs();

	// Create background music
	SoundManager::Get()->GetSystem()->getChannel(0, &m_pBackgroundMusicChannel);
	auto result = SoundManager::Get()->GetSystem()->createStream("Resources/Audio/LevelMusic.mp3", FMOD_LOOP_NORMAL, 0, &m_pBackgroundMusic);
	SoundManager::CheckResult(result);

}

void MainScene::InitCharacter()
{

	// Character settings
	const auto pCharacterPhysicsMaterial = PxGetPhysics().createMaterial(0.5f, 0.5f, 0.5f);
	MainCharacterDesc characterDesc{ pCharacterPhysicsMaterial };
	characterDesc.actionId_MoveForward = CharacterMoveForward;
	characterDesc.actionId_MoveBackward = CharacterMoveBackward;
	characterDesc.actionId_MoveLeft = CharacterMoveLeft;
	characterDesc.actionId_MoveRight = CharacterMoveRight;
	characterDesc.actionId_Jump = CharacterJump;
	characterDesc.actionId_ShootBlue = GunShootBlue;
	characterDesc.actionId_ShootRed = GunShootRed;
	characterDesc.rotationSpeed = 10.0f;

	// Create character
	m_pCharacter = AddChild(new MainCharacter(characterDesc));
	m_pCharacter->GetTransform()->Translate(0.f, 5.f, 0.f);
	m_pCharacter->SetFocus(true); // Give control to the character (disable if pause menu is active)


}

void MainScene::onWinCondition(GameObject* /*pTrigger*/, GameObject* pOther, PxTriggerAction action)
{
	if(action != PxTriggerAction::ENTER)
		return;

	if(pOther == m_pCharacter)
	{
		// Return to main menu		
		PauseMusic();
		auto pSceneManager = SceneManager::Get();
		pSceneManager->SetActiveGameScene(L"MainMenu");

	}
}

void MainScene::InitInputs()
{
	auto inputAction = InputAction(CharacterMoveLeft, InputState::down, 'A');
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(CharacterMoveRight, InputState::down, 'D');
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(CharacterMoveForward, InputState::down, 'W');
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(CharacterMoveBackward, InputState::down, 'S');
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(CharacterJump, InputState::pressed, VK_SPACE, -1, XINPUT_GAMEPAD_A);
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(OpenPauseMenu, InputState::pressed, VK_ESCAPE);
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(GunShootBlue, InputState::pressed, -1, VK_LBUTTON);
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(GunShootRed, InputState::pressed, -1,  VK_RBUTTON);
	m_SceneContext.pInput->AddInputAction(inputAction);

	inputAction = InputAction(ClearPortals, InputState::pressed, 'C');
	m_SceneContext.pInput->AddInputAction(inputAction);
}

void MainScene::PostInitialize()
{
	SoundManager::Get()->GetSystem()->playSound(m_pBackgroundMusic, 0, false, &m_pBackgroundMusicChannel);
	m_pBackgroundMusicChannel->setVolume(0.1f);
}

void MainScene::Update()
{
	InputManager::ForceMouseToCenter( m_pCharacter->IsFocused());
	
	if(m_SceneContext.pInput->IsActionTriggered(InputIds::ClearPortals))
	{
		Portal::ClearPortals();
	}

	
	if(m_SceneContext.pInput->IsActionTriggered(InputIds::OpenPauseMenu))
	{
		m_pCharacter->SetFocus(not m_pCharacter->IsFocused());

		if(m_pCharacter->IsFocused())
		{
			m_pPauseMenu->Close();

			ResumeMusic();
		}
		else
		{
			m_pPauseMenu->Open();
			PauseMusic();
		}
	}

	if(not m_pPauseMenu->IsActive() && not m_pCharacter->IsFocused())
	{
		m_pCharacter->SetFocus(true);
		ResumeMusic();

	}
	m_pPostChromatic->SetIsEnabled(m_pCharacter->IsFocused());

	m_pHud->UpdateCrosshair(Portal::HasBluePortal(), Portal::HasRedPortal());


}

void MainScene::OnGUI()
{
	m_pCharacter->DrawImGui();
}

void MainScene::CreateLevel()
{
	// Default level material
	const auto pDefaultMaterial = PxGetPhysics().createMaterial(0.5f, 0.5f, 0.5f);

	auto* pFloorMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pFloorMaterial->SetDiffuseTexture(L"Textures/world/concrete_modular_floor2.png");

	auto* pWallsMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pWallsMaterial->SetDiffuseTexture(L"Textures/world/concrete_modular_wall5.png");

	auto* pRoofMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pRoofMaterial->SetDiffuseTexture(L"Textures/world/concrete_modular_ceiling1.png");

	auto* pStairsMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pStairsMaterial->SetDiffuseTexture(L"Textures/world/metal_modular_floor2.png");

	// Floor
	GameObject* pLevelObject = AddChild(new GameObject());
	ModelComponent* pLevelMesh = pLevelObject->AddComponent(new ModelComponent(L"Meshes/World/Level_0/levelFloor.ovm"));
	pLevelMesh->SetMaterial(pFloorMaterial);

	RigidBodyComponent* pLevelActor = pLevelObject->AddComponent(new RigidBodyComponent(true));
	auto pPxTriangleMesh = ContentManager::Load<PxTriangleMesh>(L"Meshes/World/Level_0/levelFloor.ovpt");
	pLevelActor->AddCollider(PxTriangleMeshGeometry(pPxTriangleMesh, PxMeshScale({ .5f,.5f,.5f })), *pDefaultMaterial);
	pLevelObject->GetTransform()->Scale(.5f, .5f, .5f);

	// Walls
	pLevelObject = AddChild(new GameObject());
	pLevelMesh = pLevelObject->AddComponent(new ModelComponent(L"Meshes/World/Level_0/levelWalls.ovm"));
	pLevelMesh->SetMaterial(pWallsMaterial);
	pLevelObject->SetTag(L"CanSpawnPortal");

	pLevelActor = pLevelObject->AddComponent(new RigidBodyComponent(true));
	pPxTriangleMesh = ContentManager::Load<PxTriangleMesh>(L"Meshes/World/Level_0/levelWalls.ovpt");
	pLevelActor->AddCollider(PxTriangleMeshGeometry(pPxTriangleMesh, PxMeshScale({ .5f,.5f,.5f })), *pDefaultMaterial);
	pLevelObject->GetTransform()->Scale(.5f, .5f, .5f);

	// Stairs
	pLevelObject = AddChild(new GameObject());
	pLevelMesh = pLevelObject->AddComponent(new ModelComponent(L"Meshes/World/Level_0/levelStairs.ovm"));
	pLevelMesh->SetMaterial(pStairsMaterial);

	pLevelActor = pLevelObject->AddComponent(new RigidBodyComponent(true));
	pPxTriangleMesh = ContentManager::Load<PxTriangleMesh>(L"Meshes/World/Level_0/levelStairs.ovpt");
	pLevelActor->AddCollider(PxTriangleMeshGeometry(pPxTriangleMesh, PxMeshScale({ .5f,.5f,.5f })), *pDefaultMaterial);
	pLevelObject->GetTransform()->Scale(.5f, .5f, .5f);

	// Roof
	pLevelObject = AddChild(new GameObject());
	pLevelMesh = pLevelObject->AddComponent(new ModelComponent(L"Meshes/World/Level_0/levelRoof.ovm"));
	pLevelMesh->SetMaterial(pRoofMaterial);

	pLevelActor = pLevelObject->AddComponent(new RigidBodyComponent(true));
	pPxTriangleMesh = ContentManager::Load<PxTriangleMesh>(L"Meshes/World/Level_0/levelRoof.ovpt");
	pLevelActor->AddCollider(PxTriangleMeshGeometry(pPxTriangleMesh, PxMeshScale({ .5f,.5f,.5f })), *pDefaultMaterial);
	pLevelObject->GetTransform()->Scale(.5f, .5f, .5f);

	// Invisible colliders
	pLevelObject = AddChild(new GameObject());
	pLevelActor = pLevelObject->AddComponent(new RigidBodyComponent(true));
	pPxTriangleMesh = ContentManager::Load<PxTriangleMesh>(L"Meshes/World/Level_0/levelColliders.ovpt");
	pLevelActor->AddCollider(PxTriangleMeshGeometry(pPxTriangleMesh, PxMeshScale({ .5f,.5f,.5f })), *pDefaultMaterial);
	pLevelObject->GetTransform()->Scale(.5f, .5f, .5f);

	// Win condition trigger
	auto color = XMFLOAT4(Colors::Lime);
	color.z = 0.5f;
	auto pTrigger = new CubePrefab(5.f, 5.f, 5.f, color);
	pTrigger->GetTransform()->Translate(-65.0f, 5.0f, 50.f);
	AddChild(pTrigger);

	auto pRigidBody = pTrigger->AddComponent(new RigidBodyComponent(false));
	pRigidBody->AddCollider(PxBoxGeometry{ 5.f, 5.f, 1.f }, *pDefaultMaterial, true);
	pRigidBody->SetKinematic(true);

	pTrigger->SetOnTriggerCallBack([=](GameObject* pTrigger, GameObject* pOther, PxTriggerAction action) {
		onWinCondition(pTrigger, pOther, action);
	});

	m_pPostChromatic = MaterialManager::Get()->CreateMaterial<PostChromatic>();
	AddPostProcessingEffect(m_pPostChromatic);
}

void MainScene::PauseMusic()
{
	m_pBackgroundMusicChannel->setPaused(true);
}

void MainScene::ResumeMusic()
{
	m_pBackgroundMusicChannel->setPaused(false);
}
