#pragma once

class Button;
class Cursor;
class MainMenu: public GameScene
{
public:
	MainMenu();
	~MainMenu();

	MainMenu(const MainMenu& other) = delete;
	MainMenu(MainMenu&& other) noexcept = delete;
	MainMenu& operator=(const MainMenu& other) = delete;
	MainMenu& operator=(MainMenu&& other) noexcept = delete;

protected:
	void Initialize() override;
	void PostInitialize() override;
	void Update() override;
	void Draw() override;
	void OnGUI() override;
	void OnSceneActivated() override;
	void OnSceneDeactivated() override;

private:
	GameObject* m_pBackground{ nullptr };

	FMOD::Channel* m_pBackgroundMusicChannel{ nullptr };
	FMOD::Sound* m_pBackgroundMusic{ nullptr };

	std::vector<Button*> m_Buttons{};

	SpriteFont* m_pPortalFont{ nullptr };

	Cursor* m_pCursor{ nullptr };


	void PauseSounds();
	void ResumeSounds();
};

