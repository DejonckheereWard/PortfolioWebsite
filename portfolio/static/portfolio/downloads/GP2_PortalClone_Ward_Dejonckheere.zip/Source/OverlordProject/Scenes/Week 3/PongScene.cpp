#include "stdafx.h"
#include "PongScene.h"
#include "Prefabs/CubePrefab.h"
#include "Prefabs/SpherePrefab.h"
#include "Prefabs/FixedCamera.h"
//#include "Base/Logger.h"

PongScene::PongScene():
	GameScene(L"PongScene")
{}

void PongScene::Initialize()
{
	// SETTINGS
	m_SceneContext.settings.enableOnGUI = false;
	m_SceneContext.settings.clearColor = XMFLOAT4{ Colors::Black };
	m_SceneContext.settings.drawGrid = false;
	m_SceneContext.settings.drawUserDebug = false;
	m_SceneContext.settings.drawPhysXDebug = false;


	m_pFixedCamera = new FixedCamera();
	m_pFixedCamera->GetTransform()->Translate(0, 50.0f, 0.f);
	m_pFixedCamera->GetTransform()->Rotate(90.0f, 0.f, 0.f);
	AddChild(m_pFixedCamera);
	SetActiveCamera(m_pFixedCamera->GetComponent<CameraComponent>());
		
		
	// PhysX
	auto& physx{ PxGetPhysics() };
	auto pBouncyMaterial{ physx.createMaterial(.0f, .0f, 1.05f) };

	// ARENA TOP
	auto pActor = physx.createRigidStatic(PxTransform{ 0.0f, 0.0f, 20.0f, PxQuat{PxPiDivTwo, PxVec3{0.f,1.f,0.f}} });
	PxRigidActorExt::createExclusiveShape(*pActor, PxPlaneGeometry{}, *pBouncyMaterial);
	GetPhysxProxy()->AddActor(*pActor);

	// ARENA BOT
	pActor = physx.createRigidStatic(PxTransform{ 0.0f, 0.0f, -20.0f, PxQuat{-PxPiDivTwo, PxVec3{0.f,1.f,0.f}} });
	PxRigidActorExt::createExclusiveShape(*pActor, PxPlaneGeometry{}, *pBouncyMaterial);
	GetPhysxProxy()->AddActor(*pActor);


	// Left Paddle
	m_pLeftPaddle = new CubePrefab(1.0f, 1.0f, 5.0f, XMFLOAT4{ Colors::Gray });
	m_pLeftPaddle->GetTransform()->Translate(-30.5f, 0.f, 0.f);
	AddChild(m_pLeftPaddle);

	auto pRigidBody{ m_pLeftPaddle->AddComponent(new RigidBodyComponent(false)) };
	pRigidBody->AddCollider(PxBoxGeometry{ 0.5f, 0.5f, 2.5f }, *pBouncyMaterial);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransY, false);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransX, false);
	pRigidBody->SetKinematic(true);

	// Right Paddle
	m_pRightPaddle = new CubePrefab(1.0f, 1.0f, 5.0f, XMFLOAT4{ Colors::Gray });
	m_pRightPaddle->GetTransform()->Translate(30.0f, 0.f, 0.f);
	AddChild(m_pRightPaddle);

	pRigidBody = m_pRightPaddle->AddComponent(new RigidBodyComponent(false));
	pRigidBody->AddCollider(PxBoxGeometry{ 0.5f, 0.5f, 2.5f }, *pBouncyMaterial);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransY, false);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransX, false);
	pRigidBody->SetKinematic(true);

	InitBall(pBouncyMaterial);


	// Left Goal Trigger
	m_pLeftTrigger = new CubePrefab(2.0f, 20.0f, 100.0f, XMFLOAT4(Colors::Transparent));
	m_pLeftTrigger->GetTransform()->Translate(-35.0f, 0.0f, 0.f);
	AddChild(m_pLeftTrigger);
	pRigidBody = m_pLeftTrigger->AddComponent(new RigidBodyComponent(false));
	pRigidBody->AddCollider(PxBoxGeometry{ 1.0f, 10.0f, 50.0f }, *pBouncyMaterial, true);
	pRigidBody->SetKinematic(true);
	m_pLeftTrigger->SetOnTriggerCallBack([=](GameObject* pTrigger, GameObject* pOther, PxTriggerAction action) {
		onTrigger(pTrigger, pOther, action);
	});


	//Right Goal Trigger
	m_pRightTrigger = new CubePrefab(2.0f, 20.0f, 100.0f, XMFLOAT4(Colors::Transparent));
	m_pRightTrigger->GetTransform()->Translate(35.0f, 0.0f, 0.f);
	AddChild(m_pRightTrigger);
	pRigidBody = m_pRightTrigger->AddComponent(new RigidBodyComponent(false));
	pRigidBody->AddCollider(PxBoxGeometry{ 1.0f, 10.0f, 50.0f }, *pBouncyMaterial, true);
	pRigidBody->SetKinematic(true);

	m_pRightTrigger->SetOnTriggerCallBack([=](GameObject* pTrigger, GameObject* pOther, PxTriggerAction action) {
		onTrigger(pTrigger, pOther, action);
	});
};


void PongScene::Update()
{
	const float deltaTime{ m_SceneContext.pGameTime->GetElapsed() };
	const float paddleSpeed{ 20.0f * deltaTime };


	// LEFT PADDLE
	if(m_SceneContext.pInput->IsKeyboardKey(InputState::down, 'S'))
	{
		auto lastPosition = m_pLeftPaddle->GetTransform()->GetPosition();
		lastPosition.z -= paddleSpeed;
		m_pLeftPaddle->GetTransform()->Translate(lastPosition);
	}

	if(m_SceneContext.pInput->IsKeyboardKey(InputState::down, 'W'))
	{
		auto lastPosition = m_pLeftPaddle->GetTransform()->GetPosition();
		lastPosition.z += paddleSpeed;
		m_pLeftPaddle->GetTransform()->Translate(lastPosition);
	}

	// RIGHT PADDLE
	if(m_SceneContext.pInput->IsKeyboardKey(InputState::down, VK_DOWN))
	{
		auto lastPosition = m_pRightPaddle->GetTransform()->GetPosition();
		lastPosition.z -= paddleSpeed;
		m_pRightPaddle->GetTransform()->Translate(lastPosition);
	}

	if(m_SceneContext.pInput->IsKeyboardKey(InputState::down, VK_UP))
	{
		auto lastPosition = m_pRightPaddle->GetTransform()->GetPosition();
		lastPosition.z += paddleSpeed;
		m_pRightPaddle->GetTransform()->Translate(lastPosition);
	}



	if(m_IsLeftTriggered || m_IsRightTriggered)
	{
		ResetScene();
	}
}

void PongScene::InitBall(PxMaterial* physxMaterial)
{
	if(physxMaterial == nullptr)
	{
		auto& physx = PxGetPhysics();
		physxMaterial = physx.createMaterial(.0f, .0f, 1.f);
	}

	// Ball
	m_pBall = new SpherePrefab(0.75f, 16, XMFLOAT4{ Colors::Red });
	m_pBall->GetTransform()->Translate(0.f, 0.f, 0.f);
	AddChild(m_pBall);
	auto pRigidBody = m_pBall->AddComponent(new RigidBodyComponent(false));
	pRigidBody->AddCollider(PxSphereGeometry{ 0.75f }, *physxMaterial);
	pRigidBody->SetConstraint(RigidBodyConstraint::TransY, false);
	pRigidBody->SetDensity(1.0f);
	pRigidBody->AddForce(XMFLOAT3{ 20.0f, 0.0f, 5.0f }, PxForceMode::eIMPULSE);  // INIT FORCE
}

void PongScene::ResetBall()
{
	m_pBall->GetTransform()->Translate(0.f, 0.f, 0.f);
	m_pBall->GetComponent<RigidBodyComponent>()->AddForce(XMFLOAT3{ 20.0f, 0.0f, 1.0f }, PxForceMode::eIMPULSE);
	
}

void PongScene::onTrigger(GameObject* pTrigger, GameObject* pOther, PxTriggerAction action)
{	
	if(pOther != m_pBall)
		return;

	if(pTrigger == m_pLeftTrigger)
	{
		if(action == PxTriggerAction::ENTER)  // ENTERED TRIGGER
		{
			m_IsLeftTriggered = true;
		}
		else if(action == PxTriggerAction::LEAVE) // EXITED TRIGGER
		{
			m_IsLeftTriggered = false;
		}
	}
	else if(pTrigger == m_pRightTrigger)
	{
		if(action == PxTriggerAction::ENTER)  // ENTERED TRIGGER
		{
			m_IsRightTriggered = true;
		}
		else if(action == PxTriggerAction::LEAVE) // EXITED TRIGGER
		{
			m_IsRightTriggered = false;
		}
	}
}

void PongScene::ResetScene()
{
	ResetBall();
	m_IsLeftTriggered = false;
	m_IsRightTriggered = false;
}
