#include "stdafx.h"
#include "PostChromatic.h"

PostChromatic::PostChromatic():
	PostProcessingMaterial(L"Effects/Post/ChromaticAberration.fx")
{
}
