#include "stdafx.h"
#include "DiffuseMaterial_Shadow_Skinned.h"

DiffuseMaterial_Shadow_Skinned::DiffuseMaterial_Shadow_Skinned():
	Material(L"Effects/Shadow/PosNormTex3D_Shadow_Skinned.fx")
{}

void DiffuseMaterial_Shadow_Skinned::SetDiffuseTexture(const std::wstring& assetFile)
{
	m_pDiffuseTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gDiffuseMap", m_pDiffuseTexture);
}

void DiffuseMaterial_Shadow_Skinned::InitializeEffectVariables()
{
}

void DiffuseMaterial_Shadow_Skinned::OnUpdateModelVariables(const SceneContext& sceneContext, const ModelComponent* pModel) const
{
	/*
	 * TODO_W8
	 * Update The Shader Variables
	 * 1. Update the LightWVP > Used to Transform a vertex into Light clipping space
	 * 	LightWVP = model_world * light_viewprojection
	 * 	(light_viewprojection [LightVP] can be acquired from the ShadowMapRenderer)
	 * 
	 * 2. Update the ShadowMap texture
	 * 
	 * 3. Update the Light Direction (retrieve the direction from the LightManager > sceneContext)
	 * 
	 * 4. Update Bones
	*/

	//Update Shadow Variables
	//const auto pShadowMapRenderer = ShadowMapRenderer::Get();
	//...

	const XMFLOAT4X4& modelWorldTransform{ pModel->GetTransform()->GetWorld() };
	const XMFLOAT4X4& lightViewProjection{ ShadowMapRenderer::Get()->GetLightVP() };

	XMMATRIX lightWorldViewProjection{
		XMMatrixMultiply(XMLoadFloat4x4(&modelWorldTransform), XMLoadFloat4x4(&lightViewProjection))
	};

	// Set the light WVP matrix in the shader
	SetVariable_Matrix(L"gWorldViewProj_Light", reinterpret_cast<const float*>(lightWorldViewProjection.r));

	// Set the shadow map
	SetVariable_Texture(L"gShadowMap", ShadowMapRenderer::Get()->GetShadowMap());

	// Get and Update light direction
	const Light& directionalLight{ sceneContext.pLights->GetDirectionalLight() };
	SetVariable_Vector(L"gLightDirection", directionalLight.direction);

	// Update Bones (copied from diffuse material skinned)
    ModelAnimator* modelAnimator{ pModel->GetAnimator() };
	ASSERT_NULL_(modelAnimator);
	auto boneTransforms = modelAnimator->GetBoneTransforms();
	SetVariable_MatrixArray(L"gBones", reinterpret_cast<float*>(boneTransforms.data()), static_cast<UINT>(boneTransforms.size()));
}
