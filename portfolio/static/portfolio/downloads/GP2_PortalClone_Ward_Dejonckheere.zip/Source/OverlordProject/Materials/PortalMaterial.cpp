#include "stdafx.h"
#include "PortalMaterial.h"

PortalMaterial::PortalMaterial():
	Material<PortalMaterial>(L"Effects/PortalShader.fx")
{
}

void PortalMaterial::SetPortalMap(ID3D11ShaderResourceView* portalMap)
{
	m_pPortalMap = portalMap;
	SetVariable_Texture(L"gPortalMap", m_pPortalMap);
}

void PortalMaterial::SetPortalColor(const DirectX::XMFLOAT4& color)
{
	m_PortalColor = color;
	SetVariable_Vector(L"gPortalColor", m_PortalColor);

}

void PortalMaterial::InitializeEffectVariables()
{
}
