#include "stdafx.h"
#include "SpikyMaterial.h"

SpikyMaterial::SpikyMaterial():
	Material<SpikyMaterial>(L"Effects/SpikyShader.fx")
{
}

void SpikyMaterial::InitializeEffectVariables()
{
	SetVariable_Vector(L"m_LightDirection", { 0.577f, 0.577f, -0.577f });
	SetVariable_Vector(L"gColorDiffuse", {1.0f, 0.2f, 0.2f, 1.0f});
}
