#include "stdafx.h"
#include "UberMaterial.h"

UberMaterial::UberMaterial():
	Material<UberMaterial>(L"Effects/UberShader.fx")
{
}

void UberMaterial::SetDiffuseTexture(const std::wstring& assetFile)
{
	m_pDiffuseTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gTextureDiffuse", m_pDiffuseTexture);
}

void UberMaterial::SetSpecularTexture(const std::wstring& assetFile)
{
	m_pSpecularTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gTextureSpecularIntensity", m_pSpecularTexture);
}

void UberMaterial::SetNormalTexture(const std::wstring& assetFile)
{
	m_pNormalTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gTextureNormal", m_pNormalTexture);
}

void UberMaterial::SetEnvironmentCubeTexture(const std::wstring& assetFile)
{
	m_pEnvironmentCubeTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gCubeEnvironment", m_pEnvironmentCubeTexture);
}

void UberMaterial::SetOpacityTexture(const std::wstring& assetFile)
{
	m_pOpacityTexture = ContentManager::Load<TextureData>(assetFile);
	SetVariable_Texture(L"gTextureOpacity", m_pOpacityTexture);
}

void UberMaterial::InitializeEffectVariables()
{
	// Directional Light
	SetVariable_Vector(L"gLightDirection", { -0.577f, -0.577f, 0.577f });

	// Diffuse
	SetVariable_Scalar(L"gUseDiffuseTexture", true);
	SetVariable_Vector(L"gColorDiffuse", { 0.82f, 0.2f, 0.2f, 1.0f });
	SetDiffuseTexture(L"Textures/Skulls_Diffusemap.tga");

	// Specular
	SetVariable_Vector(L"gColorSpecular", { 0.8f, 0.8f, 0.35f, 1.0f });
	SetVariable_Scalar(L"gUseTextureSpecularIntensity", true);
	SetSpecularTexture(L"Textures/Skulls_Heightmap.tga");
	SetVariable_Scalar(L"gShininess", 46.0f);
	SetVariable_Scalar(L"gUseSpecularBlinn", true);
	SetVariable_Scalar(L"gUseSpecularPhong", true);

	// Ambient
	SetVariable_Vector(L"gColorAmbient", { 0.8f, 0.5f, 0.4f, 1.0f });
	SetVariable_Scalar(L"gAmbientIntensity", 0.025f);

	// Normal mapping
	SetVariable_Scalar(L"gFlipGreenChannel", false);
	SetVariable_Scalar(L"gUseTextureNormal", true);
	SetNormalTexture(L"Textures/Skulls_Normalmap.tga");

	// Environment mapping

	SetVariable_Scalar(L"gUseEnvironmentMapping", true);
	SetEnvironmentCubeTexture(L"Textures/Sunol_Cubemap.dds");
	SetVariable_Scalar(L"gReflectionStrength", 0.5f);
	SetVariable_Scalar(L"gRefractionStrength", 0.1f);
	SetVariable_Scalar(L"gRefractionIndex", 0.7f);

	// Fresnel
	SetVariable_Scalar(L"gUseFresnelFalloff", true);
	SetVariable_Vector(L"gColorFresnel", { 1.0f, 1.0f, 1.0f, 1.0f });
	SetVariable_Scalar(L"gFresnelPower", 0.9f);
	SetVariable_Scalar(L"gFresnelMultiplier", 0.6f);
	SetVariable_Scalar(L"gFresnelHardness", 0.3f);

	// Opacity
	SetVariable_Scalar(L"gOpacityIntensity", 1.0f);
	SetOpacityTexture(L"Textures/Specular_Level.tga");
	SetVariable_Scalar(L"gTextureOpacityIntensity", false);



}
