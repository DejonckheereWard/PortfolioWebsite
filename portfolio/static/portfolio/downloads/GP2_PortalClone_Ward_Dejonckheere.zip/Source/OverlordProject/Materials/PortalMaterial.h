#pragma once
class PortalMaterial final: public Material<PortalMaterial>
{
public:
	PortalMaterial();
	~PortalMaterial() override = default;

	PortalMaterial(const PortalMaterial& other) = delete;
	PortalMaterial(PortalMaterial&& other) noexcept = delete;
	PortalMaterial& operator=(const PortalMaterial& other) = delete;
	PortalMaterial& operator=(PortalMaterial&& other) noexcept = delete;

	//void SetOtherPortalViewProjection(const DirectX::XMFLOAT4X4& viewProjection);

	void SetPortalMap(ID3D11ShaderResourceView* portalMap);
	void SetPortalColor(const DirectX::XMFLOAT4& color);

protected:
	void InitializeEffectVariables() override;

private:	
	XMFLOAT4 m_PortalColor{ 0.f, 1.f, 0.f, 1.f };
	ID3D11ShaderResourceView* m_pPortalMap{};

};

