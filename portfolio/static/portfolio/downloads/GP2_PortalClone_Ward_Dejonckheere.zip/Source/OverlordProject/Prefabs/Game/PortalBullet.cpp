#include "stdafx.h"
#include "PortalBullet.h"
#include <Materials/Shadow/DiffuseMaterial_Shadow.h>
#include "Prefabs/SpherePrefab.h"


PortalBullet::PortalBullet()
{
}

PortalBullet::PortalBullet(PortalColor color)
	: m_Color(color)
{
}

void PortalBullet::SetDirection(float x, float y, float z)
{
	SetDirection(XMFLOAT3(x, y, z));
}

void PortalBullet::SetDirection(const XMFLOAT3& direction)
{
	m_Direction = direction;
}

void PortalBullet::SetDirection(const XMVECTOR& direction)
{
	XMStoreFloat3(&m_Direction, direction);
}

void PortalBullet::Initialize(const SceneContext&)
{
	ParticleEmitterSettings settings{};
	settings.velocity = { 0.f,-1.f,0.f };
	settings.minSize = 1.f;
	settings.maxSize = 2.f;
	settings.minEnergy = 0.1f;
	settings.maxEnergy = 0.3f;
	settings.minScale = 0.5f;
	settings.maxScale = 1.5f;
	settings.minEmitterRadius = .0f;
	settings.maxEmitterRadius = .4f;
	settings.color = { 1.f,1.f,1.f, 0.8f };

	std::wstring texturePath{};

	// Particle texture
	switch(m_Color)
	{
		case PortalColor::Red:
			texturePath = L"Textures/Portals/particle_portal_red.png";
			break;
		case PortalColor::Blue:
			texturePath = L"Textures/Portals/particle_portal_blue.png";
			break;
	}

	m_pParticleEmitter = new ParticleEmitterComponent(texturePath, settings, 200U);
	AddComponent(m_pParticleEmitter);

	// Explosion particle emitter
	settings.velocity = { -1.f,-5.f,0.f };
	settings.minSize = 1.f;
	settings.maxSize = 2.f;
	settings.minEnergy = 0.1f;
	settings.maxEnergy = 0.3f;
	settings.minScale = 0.5f;
	settings.maxScale = 1.5f;
	settings.minEmitterRadius = .0f;
	settings.maxEmitterRadius = .4f;
	settings.color = { 1.f,1.f,1.f, 1.f };

	auto pMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pMaterial->SetDiffuseTexture(L"Textures/World/concrete_modular_ceiling1.png");


	//m_pSphere = AddChild(new SpherePrefab(0.1f, 12, XMFLOAT4{Colors::Gray}));



}

void PortalBullet::Update(const SceneContext& sceneContext)
{
	if(!m_IsActive)
		return;

	const float elapsedSec{ sceneContext.pGameTime->GetElapsed() };


	// Check for collision
	PxVec3 origin{ PhysxHelper::ToPxVec3(GetTransform()->GetWorldPosition()) };
	PxVec3 rayDirection{ PhysxHelper::ToPxVec3(m_Direction) };

	auto physxProxy = SceneManager::Get()->GetActiveScene()->GetPhysxProxy();

	PxQueryFilterData filterData{};
	filterData.data.word0 = ~UINT(CollisionGroup::Group9 | CollisionGroup::Group1);  // Ignore player and other bullets

	PxRaycastBuffer outHit{};
	if(physxProxy->Raycast(origin, rayDirection, m_Speed * elapsedSec, outHit, PxHitFlag::eDEFAULT, filterData))
	{
		HandleCollision(outHit);
	}

	XMVECTOR currentPos{ XMLoadFloat3(&GetTransform()->GetPosition()) };
	XMVECTOR direction{ XMLoadFloat3(&m_Direction) };
	XMVECTOR newPos{ currentPos + direction * m_Speed * elapsedSec };
	GetTransform()->Translate(newPos);
}


void PortalBullet::HandleCollision(const PxRaycastBuffer& hit)
{
	m_IsActive = false;
	m_pParticleEmitter->Disable();



	if(m_OnCollision)
		m_OnCollision(hit);
}
