#include "stdafx.h"
#include "Portal.h"

#include "Prefabs/CubePrefab.h"

#include "Materials/PortalMaterial.h"

#include "Prefabs/Game/MainCharacter.h"

Portal* Portal::m_pRedPortal = nullptr;
Portal* Portal::m_pBluePortal = nullptr;

float Portal::m_Height{ 4.f };
float Portal::m_Width{ 2.f };

size_t Portal::m_PortalRenderDepth{ 6 };  // How many times the portal can render another portal


Portal::Portal()
{
}

Portal::Portal(PortalColor color):
	m_Color(color)
{
}

Portal::~Portal()
{
	m_pSoundChannel->stop();
	XMFLOAT3 pos = GetTransform()->GetPosition();
	FMOD_VECTOR fmodPos = { pos.x, pos.y, pos.z };
	m_pSoundChannel->set3DAttributes(&fmodPos, nullptr);
	m_pSoundSystem->playSound(m_pPortalClose, nullptr, false, &m_pSoundChannel);
}

void Portal::SetCameraRotation(const XMFLOAT3& eulerRotation)
{
	ASSERT_NULL_(m_pCamera);

	m_pCamera->GetTransform()->Rotate(eulerRotation);
}

void Portal::StartRender(const SceneContext& sceneContext)
{
	// Draw portal to render target
	m_pRenderTarget->Clear();

	Portal* pOtherPortal{ nullptr };
	if(m_Color == PortalColor::Red)
	{
		pOtherPortal = m_pBluePortal;
	}
	else
	{
		pOtherPortal = m_pRedPortal;
	}

	if(pOtherPortal == nullptr)
	{
		return;
	}


	constexpr ID3D11ShaderResourceView* const pSRV[] = { nullptr };
	sceneContext.d3dContext.pDeviceContext->PSSetShaderResources(1, 1, pSRV);

	// Set render target
	GetScene()->GetGame()->SetRenderTarget(m_pRenderTarget);
	//m_pRenderTarget->Clear();  // Clear old data

	GetScene()->SetActiveCamera(pOtherPortal->GetCamera());


}

void Portal::StopRender(const SceneContext& /*sceneContext*/)
{
	Portal* pOtherPortal{ nullptr };
	if(m_Color == PortalColor::Red)
	{
		pOtherPortal = m_pBluePortal;
	}
	else
	{
		pOtherPortal = m_pRedPortal;
	}

	if(pOtherPortal == nullptr)
	{
		return;
	}

	// Save the texture to the portal material
	m_pPortalMaterial->SetPortalMap(m_pRenderTarget->GetColorShaderResourceView());

	// Return to defaults
	GetScene()->GetGame()->SetRenderTarget(nullptr);
	GetScene()->SetActiveCamera(nullptr);
}


bool Portal::CanSpawnPortal(const XMFLOAT3& position, const XMFLOAT3& forward)
{
	// Position is center
	// Forward is direction

	// Raycast left to right
	// Raycast bottom to top

	// If any fails return false
	// else return true

	// Get physx proxy
	auto* pPhysxProxy = SceneManager::Get()->GetActiveScene()->GetPhysxProxy();

	const PxVec3 bottom{ PhysxHelper::ToPxVec3(XMFLOAT3{position.x, position.y - (m_Height / 2.0f), position.z}) };
	const PxVec3 upDirection{ PxVec3(0, 1, 0) };

	PxQueryFilterData filterData{};
	PxRaycastBuffer outHit;
	if(pPhysxProxy->Raycast(bottom, upDirection, m_Height, outHit, PxHitFlag::eDEFAULT, filterData))
	{
		return false;
	}

	// Get right vector, using the foward vector and world up

	XMVECTOR rightVector{ XMVector3Cross(XMLoadFloat3(&forward), XMVectorSet(0, 1.0f, 0.f, 0.f)) };
	XMFLOAT3 rightDirection{};
	XMStoreFloat3(&rightDirection, rightVector);

	XMFLOAT3 leftPosition{};
	XMStoreFloat3(&leftPosition, XMLoadFloat3(&position) - (rightVector * (m_Width / 2.0f)));

	if(pPhysxProxy->Raycast(PhysxHelper::ToPxVec3(leftPosition), PhysxHelper::ToPxVec3(rightDirection), m_Width, outHit, PxHitFlag::eDEFAULT, filterData))
	{
		return false;
	}

	return true;
}

void Portal::ClearPortals()
{
	// Remove references to possible broken portals (cleanup scene)
	m_pBluePortal = nullptr;
	m_pRedPortal = nullptr;
}

void Portal::Initialize(const SceneContext& sceneContext)
{
	// Init render target	
	//render target

	RENDERTARGET_DESC renderTargetDesc;
	renderTargetDesc.width = static_cast<UINT>(sceneContext.windowHeight / 2.0f);
	renderTargetDesc.height = static_cast<UINT>(sceneContext.windowHeight);
	renderTargetDesc.enableColorBuffer = true;
	renderTargetDesc.enableColorSRV = true;
	renderTargetDesc.enableDepthBuffer = true;
	renderTargetDesc.enableDepthSRV = true;

	m_pRenderTarget = new RenderTarget{ sceneContext.d3dContext };
	HRESULT hResult{ m_pRenderTarget->Create(renderTargetDesc) };
	if(FAILED(hResult))
	{
		Logger::LogWarning(L"Portal::Initialize() > Failed to create PortalRenderTarget");
		return;
	}

	// Get material
	m_pPortalMaterial = MaterialManager::Get()->CreateMaterial<PortalMaterial>();

	switch(m_Color)
	{
		case PortalColor::Red:
			m_pPortalMaterial->SetPortalColor(XMFLOAT4{ 0.8f, 0.1f, 0.1f, 1.f });
			break;
		case PortalColor::Blue:
			m_pPortalMaterial->SetPortalColor(XMFLOAT4{ 0.1f, 0.1f, 0.8f, 1.f });
			break;
	}
	// Check if portal already exists
	// If so, delete it

	auto pGameScene{ SceneManager::Get()->GetActiveScene() };

	if(m_pRedPortal && m_Color == PortalColor::Red)
	{
		pGameScene->RemoveChild(m_pRedPortal);
		delete m_pRedPortal;
		m_pRedPortal = nullptr;
	}
	if(m_pBluePortal && m_Color == PortalColor::Blue)
	{
		pGameScene->RemoveChild(m_pBluePortal);
		delete m_pBluePortal;
		m_pBluePortal = nullptr;
	}


	XMFLOAT4 color{};
	switch(m_Color)
	{
		case PortalColor::Red:
			color = XMFLOAT4{ 1.f, 0.f, 0.f, 1.f };
			break;
		case PortalColor::Blue:
			color = XMFLOAT4{ 0.f, 0.f, 1.f, 1.f };
			break;
		default:
			break;
	}

	//pMaterial->SetColor(color);

	// Create portal
	auto* pPortal = AddChild(new GameObject());
	auto* pPortalModel = pPortal->AddComponent(new ModelComponent(L"Meshes/UnitPlane.ovm", false));
	pPortalModel->SetMaterial(m_pPortalMaterial);

	pPortal->GetTransform()->Rotate(90.0f, 180.f, 0.f);
	pPortal->GetTransform()->Scale(m_Width / 10.0f, 1.0f, m_Height / 10.0f);
	pPortal->GetTransform()->Translate(0, 0, 0.1f);

	switch(m_Color)
	{
		case PortalColor::Red:
			m_pRedPortal = this;
			break;
		case PortalColor::Blue:
			m_pBluePortal = this;
			break;
		default:
			break;
	}

	// Create second camera
	auto pCameraObject = AddChild(new FixedCamera());
	m_pCamera = pCameraObject->GetComponent<CameraComponent>();
	m_pCamera->SetNearClippingPlane(1.0f);
	m_pCamera->SetFieldOfView(120.0f);
	pCameraObject->GetTransform()->Rotate(0.f, 0.f, 0.f);
	pCameraObject->GetTransform()->Translate(0, 0, 0.1f);

	// Create trigger volume for portal
	auto pPhysx = PhysXManager::Get()->GetPhysics();
	auto pDefaultMaterial{ pPhysx->createMaterial(.0f, .0f, 1.05f) };
	//auto pTrigger = AddChild(new CubePrefab(m_Width, m_Height, 0.5f, XMFLOAT4(Colors::Transparent)));

	//pTrigger->GetTransform()->Translate(0.0, 0.0f, 0.f);

	auto pRigidBody = this->AddComponent(new RigidBodyComponent(false));
	PxVec3 pxVecPos{ PhysxHelper::ToPxVec3(this->GetTransform()->GetWorldPosition()) };
	pRigidBody->AddCollider(PxBoxGeometry{ m_Width / 2.0f, m_Height / 2.0f, 0.25f }, *pDefaultMaterial, true, PxTransform{ pxVecPos });
	pRigidBody->SetKinematic(true);
	this->SetOnTriggerCallBack([=](GameObject* pTrigger, GameObject* pOther, PxTriggerAction action) {
		onTrigger(pTrigger, pOther, action);
	});



	// Init Sounds
	m_pSoundSystem = SoundManager::Get()->GetSystem();
	auto result = m_pSoundSystem->getChannel(2, &m_pSoundChannel);
	result = m_pSoundSystem->createSound("Resources/Audio/PortalAmbient.wav", FMOD_3D | FMOD_LOOP_NORMAL, nullptr, &m_pPortalAmbient);
	result = m_pSoundSystem->createSound("Resources/Audio/PortalClose.wav", FMOD_3D, nullptr, &m_pPortalClose);
	result = m_pPortalAmbient->set3DMinMaxDistance(0.5f, 100.0f);
	result = m_pPortalClose->set3DMinMaxDistance(0.5f, 100.0f);
	result = m_pSoundSystem->playSound(m_pPortalAmbient, nullptr, false, &m_pSoundChannel);
	SoundManager::CheckResult(result);

	XMFLOAT3 pos = GetTransform()->GetPosition();
	FMOD_VECTOR fmodPos = { pos.x, pos.y, pos.z };
	m_pSoundChannel->set3DAttributes(&fmodPos, nullptr);



}

void Portal::Update(const SceneContext&)
{
	//if(m_pOriginalCamera == nullptr)
	//{
	//	m_pOriginalCamera = GetScene()->GetActiveCamera();
	//}

	// Set camera angle according to other portal

	Portal* pOtherPortal{ nullptr };
	if(m_Color == PortalColor::Red)
	{
		pOtherPortal = m_pBluePortal;
	}
	else
	{
		pOtherPortal = m_pRedPortal;
	}

	if(pOtherPortal == nullptr)
	{
		return;
	}


	auto otherForward = pOtherPortal->GetTransform()->GetForward();
	auto thisForward = GetTransform()->GetForward();

	// Get Yaw rotation of the nrmal
	otherForward.y = 0;
	thisForward.y = 0;

	float a = atan2(thisForward.x, thisForward.z);
	//float b = atan2(otherForward.x, otherForward.z);

	//float diffYaw = b - a;




	XMFLOAT3 playerCameraPos{ GetScene()->GetActiveCamera()->GetTransform()->GetWorldPosition() };
	XMFLOAT3 portalCenter{ GetTransform()->GetWorldPosition() };



	XMFLOAT3 worldUp{ 0, 1.f, 0};
	auto matrix = XMMatrixLookAtLH(XMLoadFloat3(&portalCenter), XMLoadFloat3(&playerCameraPos), XMLoadFloat3(&worldUp));
	auto viewMatrixRotation = XMQuaternionRotationMatrix(matrix);

	viewMatrixRotation = XMQuaternionMultiply(viewMatrixRotation, XMQuaternionRotationRollPitchYaw(0, a, 0));

	pOtherPortal->GetCamera()->GetTransform()->Rotate(viewMatrixRotation);

	//// This correctly sets the world rotation as i want it, by subtracting the parent's rotation
	//auto parentQuat = pOtherPortal->GetTransform()->GetWorldRotation();
	//auto result = XMQuaternionMultiply(viewMatrixRotation, XMQuaternionInverse(XMLoadFloat4(&parentQuat)));

	//pOtherPortal->GetCamera()->GetTransform()->Rotate(result);  // Should always point the same way as the player camera

	// Remove the portal's world rotation
	//vectorToPortal = XMVector3Transform(vectorToPortal, XMMatrixInverse(nullptr, XMLoadFloat4x4(&GetTransform()->GetWorld())));

	// Remove the other portal's world rotation
	//vectorToPortal = XMVector3Transform(vectorToPortal, XMMatrixInverse(nullptr, XMLoadFloat4x4(&pOtherPortal->GetTransform()->GetWorld())));


	//XMFLOAT3 direction{};
	//XMStoreFloat3(&direction, vectorToPortal);

	//float pitch = asin(-direction.y);
	//float yaw = atan2(direction.x, direction.z);

	//pitch;
	//yaw;
	//pOtherPortal->GetCamera()->GetTransform()->Rotate(pitch, yaw, 0.0f);

	// Get the y rotation of the vector

	//MathHelper::QuaternionToEuler()


	//// Get quaternion rotation from vector to portal
	////XMVECTOR vectorToPortalQuat{ XMQuaternion };


	//// Get view matrix rotation to quaternions
	////XMVECTOR quaternion{ XMQuaternionRotationMatrix(viewMatrix) };

	////XMMATRIX viewMatrix{ XMMatrixLookToLH(XMLoadFloat3(&playerCameraPos), vectorToPortal, worldUp) };

	////// Get view matrix rotation to quaternions
	//XMVECTOR quaternion{ XMQuaternionRotationMatrix(viewMatrix) };

	////// Remove the portal's world rotation
	////quaternion = XMQuaternionMultiply(quaternion, XMQuaternionInverse(XMLoadFloat4(&GetTransform()->GetWorldRotation())));

	////// Remove the other portal's world rotation
	////quaternion = XMQuaternionMultiply(quaternion, XMLoadFloat4(&pOtherPortal->GetTransform()->GetWorldRotation()));

	////// Rotate the camera
	////pOtherPortal->GetCamera()->GetTransform()->Rotate(quaternion);


	////auto playerQuat = GetScene()->GetActiveCamera()->GetTransform()->GetWorldRotation();
}

void Portal::Draw(const SceneContext&)
{
	// Dont use draw in the portal, to prevent recursion 
}

CameraComponent* Portal::GetCamera()
{
	ASSERT_NULL_(m_pCamera);
	return m_pCamera;
}

void Portal::onTrigger(GameObject* /*pTrigger*/, GameObject* pOther, PxTriggerAction action)
{
	if(pOther->GetTag() == L"Player")
	{
		if(action == PxTriggerAction::ENTER)
		{
			// Teleport player to other portal
			// Get the other portal
			Portal* pOtherPortal{ nullptr };
			if(m_Color == PortalColor::Red)
			{
				pOtherPortal = m_pBluePortal;
			}
			else
			{
				pOtherPortal = m_pRedPortal;
			}
			if(pOtherPortal == nullptr)
			{
				return;
			}

			// Get the player's position relative to this portal
			XMFLOAT3 playerPos{ pOther->GetTransform()->GetWorldPosition() };
			XMFLOAT3 portalCenter{ GetTransform()->GetWorldPosition() };

			// Get other portal's position
			XMFLOAT3 otherPortalCenter{ pOtherPortal->GetTransform()->GetWorldPosition() };
			XMVECTOR spawnPos{ XMVectorAdd(XMLoadFloat3(&otherPortalCenter), XMLoadFloat3(&pOtherPortal->GetTransform()->GetForward()) * 2.0f) };
			
			// Set player's position
			pOther->GetTransform()->Translate(spawnPos);

			auto otherForward = pOtherPortal->GetTransform()->GetForward();
			auto thisForward = GetTransform()->GetForward();

			// Get Yaw rotation of the nrmal
			otherForward.y = 0;
			thisForward.y = 0;

			float a = atan2(thisForward.x, thisForward.z);
			float b = atan2(otherForward.x, otherForward.z);

			float diffYaw = b - a;

			MainCharacter* pMainCharacter{ static_cast<MainCharacter*>(pOther) };
			pMainCharacter->SetYaw(pMainCharacter->GetYaw() + XMConvertToDegrees(diffYaw) + 180.0f);
		}
	}
}
