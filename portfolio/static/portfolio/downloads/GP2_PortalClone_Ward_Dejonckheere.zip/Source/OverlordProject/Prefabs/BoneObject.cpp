#include "stdafx.h"
#include "BoneObject.h"

BoneObject::BoneObject(BaseMaterial* pMaterial, float length):
	m_Length{ length },
	m_pMaterial{ pMaterial }
{
}

void BoneObject::AddBone(BoneObject* pBone)
{
	pBone->GetTransform()->Translate(m_Length, 0.0f, 0.0f);
	AddChild(pBone);
}

void BoneObject::CalculateBindPose()
{
	XMStoreFloat4x4(&m_BindPose, XMMatrixInverse(nullptr, XMLoadFloat4x4(&GetTransform()->GetWorld())));

	for(BoneObject* pChild : GetChildren<BoneObject>())
	{
		pChild->CalculateBindPose();
	}
}

void BoneObject::Initialize(const SceneContext&)
{
	GameObject* pEmpty = new GameObject();
	
	ModelComponent* model = pEmpty->AddComponent(new ModelComponent(L"Meshes/Bone.ovm"));
	model->SetMaterial(m_pMaterial->GetMaterialId());
	pEmpty->GetTransform()->Rotate(0.0f, -90.0f, 0.0f);
	pEmpty->GetTransform()->Scale(m_Length);
	AddChild(pEmpty);
}
