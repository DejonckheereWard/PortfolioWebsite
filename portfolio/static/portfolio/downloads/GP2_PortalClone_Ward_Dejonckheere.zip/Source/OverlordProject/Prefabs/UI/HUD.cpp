#include "stdafx.h"
#include "HUD.h"

#include "Button.h"

HUD::HUD():
	m_OrangePortalImage{ L"Textures/UI/CrosshairOrangePortal.png" },
	m_BluePortalImage{ L"Textures/UI/CrosshairBluePortal.png" },
	m_BothPortalsImage{ L"Textures/UI/CrosshairBothPortals.png" },
	m_NoPortalsImage{ L"Textures/UI/CrosshairNoPortals.png" },
	m_CurrentImage{ m_NoPortalsImage },
	m_CrosshairGameObject{ nullptr },
	m_pCrosshairSprite{ nullptr },
	m_BluePortalExists{ false },
	m_RedPortalExists{ false }
{
}

void HUD::UpdateState(const DirectX::XMFLOAT2& mousePos, bool isPressed)
{
	for(Button* pButton : m_Buttons)
	{
		pButton->UpdateState(mousePos, isPressed);
	}
}

void HUD::UpdateCrosshair(bool bluePortalExists, bool redPortalExists)
{
	m_BluePortalExists = bluePortalExists;
	m_RedPortalExists = redPortalExists;
}

void HUD::Initialize(const SceneContext&)
{
	m_CrosshairGameObject = new GameObject();
	m_pCrosshairSprite = new SpriteComponent(m_NoPortalsImage, {0.5f, 0.5f}, DirectX::XMFLOAT4(1, 1, 1, 1.f));
	m_CrosshairGameObject->AddComponent(m_pCrosshairSprite);
	AddChild(m_CrosshairGameObject);

}

void HUD::PostInitialize(const SceneContext& sceneContext)
{
	m_CrosshairGameObject->GetTransform()->Translate(sceneContext.windowWidth / 2.0f, sceneContext.windowHeight / 2.0f, 0.5f);

}

void HUD::Update(const SceneContext&)
{


	std::wstring newImage{};
	if(m_BluePortalExists && m_RedPortalExists)
	{
		newImage = m_BothPortalsImage;
	}
	else if(m_BluePortalExists)
	{
		newImage = m_BluePortalImage;
	}
	else if(m_RedPortalExists)
	{
		newImage = m_OrangePortalImage;
	}
	else
	{
		newImage = m_NoPortalsImage;
	}

	if(m_CurrentImage != newImage)
	{
		m_CurrentImage = newImage;
		m_pCrosshairSprite->SetTexture(newImage);
	}

}

void HUD::Draw(const SceneContext&)
{
}
