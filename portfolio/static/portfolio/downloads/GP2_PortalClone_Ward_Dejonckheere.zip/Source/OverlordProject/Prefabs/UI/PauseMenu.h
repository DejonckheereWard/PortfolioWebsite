#pragma once
class Button;
class Cursor;
class PauseMenu final : public GameObject
{
public:
	PauseMenu();
	~PauseMenu() override = default;
	PauseMenu(const PauseMenu& other) = delete;
	PauseMenu(PauseMenu&& other) noexcept = delete;
	PauseMenu& operator=(const PauseMenu& other) = delete;
	PauseMenu& operator=(PauseMenu&& other) noexcept = delete;

	void Open();
	void Close();

	bool IsActive();

protected:
	void Initialize(const SceneContext&) override;
	void PostInitialize(const SceneContext&) override;
	void Update(const SceneContext&) override;
	void Draw(const SceneContext&) override;

private:

	std::vector<SpriteComponent*> m_Sprites{};

	//SpriteComponent* m_p{ nullptr };

	bool m_IsActive{false};

	Cursor* m_pCursor{ nullptr };

	std::vector<Button*> m_Buttons{};
};

