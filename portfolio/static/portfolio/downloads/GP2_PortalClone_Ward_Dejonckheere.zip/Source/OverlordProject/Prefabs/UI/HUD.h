#pragma once

class Button;
class HUD final: public GameObject
{
public:
	HUD();
	~HUD() override = default;
	HUD(const HUD& other) = delete;
	HUD(HUD&& other) noexcept = delete;
	HUD& operator=(const HUD& other) = delete;
	HUD& operator=(HUD&& other) noexcept = delete;

	void UpdateState(const DirectX::XMFLOAT2& mousePos, bool isPressed);
	void UpdateCrosshair(bool bluePortalExists, bool orangePortalExists);

protected:
	void Initialize(const SceneContext&) override;
	void PostInitialize(const SceneContext&) override;
	void Update(const SceneContext&) override;
	void Draw(const SceneContext&) override;

private:
	std::vector<Button*> m_Buttons;


	// Crosshair
	const std::wstring m_OrangePortalImage;
	const std::wstring m_BluePortalImage;
	const std::wstring m_BothPortalsImage;
	const std::wstring m_NoPortalsImage;
	std::wstring m_CurrentImage;

	GameObject* m_CrosshairGameObject;
	SpriteComponent* m_pCrosshairSprite;

	bool m_BluePortalExists;
	bool m_RedPortalExists;


};

