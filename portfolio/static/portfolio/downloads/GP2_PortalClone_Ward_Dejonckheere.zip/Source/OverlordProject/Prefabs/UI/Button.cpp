#include "stdafx.h"
#include "Button.h"

Button::Button(const std::wstring& imageUnselected, const std::wstring& imageSelected):
	m_Position{},
	m_Dimensions{},
	m_ImageUnselected{ imageUnselected },
	m_ImageSelected{ imageSelected },
	m_pSprite{ nullptr },
	m_pButtonHoverSound{ nullptr },
	m_IsMouseOver{ false },
	m_PreviousMouseOver{ m_IsMouseOver },
	m_IsPressed{ false },
	m_IsInitialized{ false }
{
	m_pSprite = new SpriteComponent(m_ImageUnselected);
	AddComponent(m_pSprite);
}
void Button::UpdateState(const DirectX::XMFLOAT2& mousePos, bool isPressed)
{
	if(!m_IsVisible)
		return;

	// Get local position
	auto pos{ GetTransform()->GetPosition() };


	// Check if the mouse is over the button
	if(mousePos.x > pos.x && mousePos.x < (pos.x + m_Dimensions.x) &&
		mousePos.y > pos.y && mousePos.y < (pos.y + m_Dimensions.y))
	{
		m_IsMouseOver = true;

		if(isPressed)
		{
			m_IsPressed = true;
		}
		else
		{
			// Click on release over button
			if(m_IsPressed)
			{
				m_IsPressed = false;
				if(m_OnClick)
					m_OnClick();
			}
		}
	}
	else
	{
		m_IsMouseOver = false;
	}

	if(m_PreviousMouseOver != m_IsMouseOver)
	{
		m_pSprite->SetTexture(m_IsMouseOver ? m_ImageSelected : m_ImageUnselected);

		if(m_IsMouseOver)
		{
			SoundManager::Get()->GetSystem()->playSound(m_pButtonHoverSound, 0, false, 0);
		}
	}

	m_PreviousMouseOver = m_IsMouseOver;

}

void Button::SetVisibility(bool isVisible)
{
	m_IsVisible = isVisible;
	m_pSprite->SetVisibility(isVisible);

}

void Button::Initialize(const SceneContext&)
{
	auto pos{ GetTransform()->GetPosition() };
	m_Position = DirectX::XMFLOAT2{ pos.x, pos.y };

	// Load sound
	auto result = SoundManager::Get()->GetSystem()->createStream("Resources/Audio/ButtonHover.wav", FMOD_LOOP_OFF, 0, &m_pButtonHoverSound);
	SoundManager::CheckResult(result);
}

void Button::PostInitialize(const SceneContext&)
{
	m_Dimensions = m_pSprite->GetDimensions();
}

void Button::Update(const SceneContext&)
{

}

void Button::Draw(const SceneContext&)
{
}
