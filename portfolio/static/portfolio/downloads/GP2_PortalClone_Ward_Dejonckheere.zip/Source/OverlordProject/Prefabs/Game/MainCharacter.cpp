#include "stdafx.h"
#include "MainCharacter.h"
#include <Materials/Shadow/DiffuseMaterial_Shadow_Skinned.h>

#include "Prefabs/Game/PortalGun.h"

MainCharacter::MainCharacter(const MainCharacterDesc& characterDesc):
	Character(characterDesc)
	, m_pCharacterModel(nullptr)
	, m_CharacterDesc(characterDesc)
{
}

void MainCharacter::Initialize(const SceneContext& sceneContext)
{
	Character::Initialize(sceneContext);
	SetTag(L"Player");
	// Load in player character mesh & textures
	const auto pPlayerMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow_Skinned>();
	pPlayerMaterial->SetDiffuseTexture(L"Textures/Character/SpacePirate_diffuse.png");

	auto pCharacterModelObject = AddChild(new GameObject());
	m_pCharacterModel = new ModelComponent(L"Models/Character.ovm");
	pCharacterModelObject->GetTransform()->Scale(0.025f);
	pCharacterModelObject->GetTransform()->Rotate(XMFLOAT3{ 0.f, 180.0f, 0.f });
	pCharacterModelObject->GetTransform()->Translate(-0.2f, -1.6f, 0.f);

	m_pCharacterModel->SetMaterial(pPlayerMaterial);
	pCharacterModelObject->AddComponent(m_pCharacterModel);

	if(const auto pAnimator = m_pCharacterModel->GetAnimator())
	{
		m_pCharacterAnimator = pAnimator;
		pAnimator->SetAnimation(m_CurrentAnimation);
		pAnimator->Play();
	}

	// Get Camera object
	auto pCamera = m_pCameraComponent->GetGameObject();

	// Create gun
	m_pPortalGun = pCamera->AddChild(new PortalGun());
	m_pPortalGun->GetTransform()->Translate(0.2f, -0.4f, 0.0f);

	m_pControllerComponent->SetCollisionGroup(CollisionGroup::Group1);
	m_pControllerComponent->SetCollisionIgnoreGroup(CollisionGroup::Group9);

}

void MainCharacter::Update(const SceneContext& sceneContext)
{
	Character::Update(sceneContext);

	// Set position for sound
	const XMFLOAT3 pos = GetTransform()->GetWorldPosition();
	const XMFLOAT3 forward = GetTransform()->GetForward();
	const XMFLOAT3 up = GetTransform()->GetUp();

	FMOD_VECTOR fmodPos = FMOD_VECTOR{ pos.x, pos.y, pos.z };
	FMOD_VECTOR fmodVel{ FMOD_VECTOR{m_TotalVelocity.x, m_TotalVelocity.y, m_TotalVelocity.z } };
	FMOD_VECTOR fmodForward{ FMOD_VECTOR{ forward.x, forward.y, forward.z } };
	FMOD_VECTOR fmodUp{ FMOD_VECTOR{ up.x, up.y, up.z } };

	auto pSoundSystem{ SoundManager::Get()->GetSystem() };
	//pSoundSystem->set3DListenerAttributes(0, &fmodPos, &fmodVel, &forward, &up);
	pSoundSystem->set3DListenerAttributes(0, &fmodPos, &fmodVel, &fmodForward, &fmodUp);

	if(m_pCharacterAnimator)
	{
		float currentSpeed{};

		XMFLOAT3 m_HorizontalVelocity{ abs(m_TotalVelocity.x), 0, abs(m_TotalVelocity.z) };
		XMStoreFloat(&currentSpeed, XMVector3Length(XMLoadFloat3(&m_HorizontalVelocity)));

		ModelAnimation m_NewAnimation{};
		if(currentSpeed >= 0.3f)
		{
			m_NewAnimation = ModelAnimation::Walk;
		}
		else
		{
			m_NewAnimation = ModelAnimation::Idle;
		}

		if(m_NewAnimation != m_CurrentAnimation)
		{
			m_pCharacterAnimator->SetAnimation(m_NewAnimation);
			m_CurrentAnimation = m_NewAnimation;
		}

		m_pCharacterAnimator->SetAnimationSpeed(currentSpeed * 0.1f);
	}

	if(not m_IsFocused)
		return;

	if(sceneContext.pInput->IsActionTriggered(m_CharacterDesc.actionId_ShootBlue))
	{
		m_pPortalGun->Shoot(PortalColor::Blue);
	}

	if(sceneContext.pInput->IsActionTriggered(m_CharacterDesc.actionId_ShootRed))
	{
		m_pPortalGun->Shoot(PortalColor::Red);
	}
}
