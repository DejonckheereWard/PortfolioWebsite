#pragma once

enum class PortalColor
{
	Red,
	Blue
};

class PortalMaterial;
class Portal final: public GameObject
{
public:
	Portal();
	Portal(PortalColor color);
	~Portal() override;
	Portal(const Portal& other) = delete;
	Portal(Portal&& other) noexcept = delete;
	Portal& operator=(const Portal& other) = delete;
	Portal& operator=(Portal&& other) noexcept = delete;

	void SetAttachedCollider(GameObject* pCollider) { m_pAttachedCollider = pCollider; };
	
	void SetCameraRotation(const XMFLOAT3& eulerRotation);


	void StartRender(const SceneContext& sceneContext);
	void StopRender(const SceneContext& sceneContext);

	static Portal* GetRedPortal() { return m_pRedPortal; };
	static Portal* GetBluePortal() { return m_pBluePortal; };

	static bool CanSpawnPortal(const XMFLOAT3& position, const XMFLOAT3& forward);

	static bool HasBluePortal() { return m_pBluePortal != nullptr; };
	static bool HasRedPortal() { return m_pRedPortal != nullptr; };

	static void ClearPortals();

	static size_t GetPortalRenderDepth() { return m_PortalRenderDepth; };

protected:
	void Initialize(const SceneContext&) override;
	void Update(const SceneContext&) override;
	void Draw(const SceneContext&) override;

private:
	FMOD::System* m_pSoundSystem{};
	FMOD::Channel* m_pSoundChannel{};

	static Portal* m_pRedPortal;
	static Portal* m_pBluePortal;
	static size_t m_PortalRenderDepth;  // How many times the portal can render another portal
	
	static float m_Height;
	static float m_Width;

	//CameraComponent* m_pOriginalCamera{};  // To restore the camera after rendering
	CameraComponent* m_pCamera{};

	PortalColor m_Color{ PortalColor::Red };
	PortalMaterial* m_pPortalMaterial{};

	FMOD::Sound* m_pPortalAmbient{};
	FMOD::Sound* m_pPortalClose{};

	RenderTarget* m_pRenderTarget{};

	CameraComponent* GetCamera();

	GameObject* m_pAttachedCollider;

	bool m_IsInPortal{};

	void onTrigger(GameObject* pTrigger, GameObject* pOther, PxTriggerAction action);
};


