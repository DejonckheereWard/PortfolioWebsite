#include "stdafx.h"
#include "Cursor.h"

Cursor::Cursor()
{
}

void Cursor::Initialize(const SceneContext&)
{
	m_pSprite = new SpriteComponent(L"Textures/UI/Cursor.png", { 0.1f, 0.1f });
	AddComponent(m_pSprite);

	InputManager::CursorVisible(false);
}

void Cursor::UpdateState(const DirectX::XMFLOAT2& mousePos)
{
	GetTransform()->Translate(mousePos.x, mousePos.y, 0.f);
}

