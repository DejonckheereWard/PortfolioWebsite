#pragma once
class Cursor final: public GameObject
{
public:
	Cursor();
	~Cursor() override = default;
	Cursor(const Cursor& other) = delete;
	Cursor(Cursor&& other) noexcept = delete;
	Cursor& operator=(const Cursor& other) = delete;
	Cursor& operator=(Cursor&& other) noexcept = delete;

	void UpdateState(const DirectX::XMFLOAT2& mousePos);

	void SetVisibility(bool isVisible) { m_pSprite->SetVisibility(isVisible); };

protected:
	void Initialize(const SceneContext&) override;

private:
	class SpriteComponent* m_pSprite{};
};

