#pragma once
class Button final : public GameObject
{
public:
	Button(const std::wstring& imageUnselected, const std::wstring& imageSelected);
	~Button() override = default;
	Button(const Button& other) = delete;
	Button(Button&& other) noexcept = delete;
	Button& operator=(const Button& other) = delete;
	Button& operator=(Button&& other) noexcept = delete;

	void SetOnClick(std::function<void()> onClick) { m_OnClick = std::move(onClick); }

	void UpdateState(const DirectX::XMFLOAT2& mousePos, bool isPressed);

	void SetVisibility(bool isVisible);

protected:
	void Initialize(const SceneContext&) override;
	void PostInitialize(const SceneContext&) override;
	void Update(const SceneContext&) override;
	void Draw(const SceneContext&) override;

private:
	bool m_IsVisible{ true };

	DirectX::XMFLOAT2 m_Position;
	DirectX::XMFLOAT2 m_Dimensions;

	const std::wstring m_ImageUnselected;
	const std::wstring m_ImageSelected;

	SpriteComponent* m_pSprite;

	FMOD::Sound* m_pButtonHoverSound;

	std::function<void()> m_OnClick;

	bool m_IsMouseOver;
	bool m_PreviousMouseOver;
	bool m_IsPressed;
	bool m_IsInitialized;

};


