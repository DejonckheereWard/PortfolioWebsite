#pragma once
#include "Prefabs/Character.h"

enum ModelAnimation: UINT
{
	Walk = 0,
	Idle = 1,
};


struct MainCharacterDesc final: public CharacterDesc
{
	MainCharacterDesc(
		PxMaterial* pMaterial,
		float radius = .5f,
		float height = 2.f):
		CharacterDesc(pMaterial, radius, height)
	{
	}

	int actionId_ShootBlue{ -1 };
	int actionId_ShootRed{ -1 };
};

class MainCharacter final: public Character
{
public:
	MainCharacter(const MainCharacterDesc& characterDesc);
	~MainCharacter() override = default;

	MainCharacter(const MainCharacter& other) = delete;
	MainCharacter(MainCharacter&& other) noexcept = delete;
	MainCharacter& operator=(const MainCharacter& other) = delete;
	MainCharacter& operator=(MainCharacter&& other) noexcept = delete;
	
	float GetYaw() const { return m_TotalYaw; }

	void SetYaw(float newYaw) 
	{ 
		m_TotalYaw = newYaw; 
	}

protected:
	void Initialize(const SceneContext&) override;

	void Update(const SceneContext&) override;

private:
	MainCharacterDesc m_CharacterDesc;

	ModelAnimation m_CurrentAnimation{ 0 };

	ModelComponent* m_pCharacterModel;
	ModelAnimator* m_pCharacterAnimator;

	class PortalGun* m_pPortalGun;



};

