#include "stdafx.h"
#include "PauseMenu.h"
#include "Button.h"
#include "Cursor.h"

PauseMenu::PauseMenu()
{
}

void PauseMenu::Open()
{
	m_IsActive = true;

	for(auto pSprite : m_Sprites)
	{
		pSprite->SetVisibility(true);
	}
	for(auto pButton : m_Buttons)
	{
		pButton->SetVisibility(true);
	}
	m_pCursor->SetVisibility(true);
}

void PauseMenu::Close()
{
	m_IsActive = false;

	for(auto pSprite : m_Sprites)
	{
		pSprite->SetVisibility(false);
	}
	for(auto pButton : m_Buttons)
	{
		pButton->SetVisibility(false);
	}
	m_pCursor->SetVisibility(false);
}

bool PauseMenu::IsActive()
{
	return m_IsActive;
}

void PauseMenu::Initialize(const SceneContext&)
{
	// Overlay
	// *******
	GameObject* pOverlay = new GameObject();
	auto pSprite = new SpriteComponent(L"Textures/UI/Overlay.png", DirectX::XMFLOAT2(0.f, 0.f));
	m_Sprites.emplace_back(pSprite);
	pOverlay->AddComponent(pSprite);
	AddChild(pOverlay);



	// Buttons
	// *******	
	// Play button
	Button* pButton = AddChild(new Button(L"Textures/UI/ResumeButton.png", L"Textures/UI/ResumeButtonSelected.png"));
	pButton->SetOnClick([this]()
	{
		Close();
	});
	m_Buttons.emplace_back(pButton);
	pButton->GetTransform()->Translate(167, 244, 0.f);

	// Quit button
	pButton = AddChild(new Button(L"Textures/UI/BackButton.png", L"Textures/UI/BackButtonSelected.png"));
	pButton->SetOnClick([]()
	{
		auto pSceneManager = SceneManager::Get();
		pSceneManager->SetActiveGameScene(L"MainMenu");
	});
	m_Buttons.emplace_back(pButton);
	pButton->GetTransform()->Translate(167, 300, 0.f);

	// Cursor
	// ******
	m_pCursor = new Cursor();
	m_pCursor->GetTransform()->Translate(XMFLOAT3{ 0, 0, 0.8f });
	AddChild(m_pCursor);


}

void PauseMenu::PostInitialize(const SceneContext&)
{
	Close();
}

void PauseMenu::Update(const SceneContext& sceneContext)
{	
	if(not m_IsActive)
		return;


	// Get mouse position
	auto mousePos = sceneContext.pInput->GetMousePosition();


	// Is mouse button pressed
	bool isPressed{ InputManager::IsMouseButton(InputState::pressed, VK_LBUTTON) };

	// Update buttons
	for(auto pButton : m_Buttons)
	{
		pButton->UpdateState(XMFLOAT2(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)), isPressed);
	}

	m_pCursor->UpdateState(XMFLOAT2(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y)));
}

void PauseMenu::Draw(const SceneContext&)
{
}
