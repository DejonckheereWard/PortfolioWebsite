#pragma once
#include <variant>
#include "Prefabs/Game/Portal.h"  // for PortalColor

class PortalBullet final: public GameObject
{
public:
	PortalBullet();
	PortalBullet(PortalColor color);
	~PortalBullet() override = default;
	PortalBullet(const PortalBullet& other) = delete;
	PortalBullet(PortalBullet&& other) noexcept = delete;
	PortalBullet& operator=(const PortalBullet& other) = delete;
	PortalBullet& operator=(PortalBullet&& other) noexcept = delete;

	void SetColor(PortalColor color) { m_Color = color; };

	void SetDirection(float x, float y, float z);
	void SetDirection(const XMFLOAT3& direction);
	void SetDirection(const XMVECTOR& direction);

	void SetActive(bool isActive) { m_IsActive = isActive; };
	bool GetActive() const { return m_IsActive; };

	void SetOnCollision(std::function<void(const PxRaycastBuffer& hit)> onCollision) { m_OnCollision = onCollision; };

protected:
	void Initialize(const SceneContext&) override;
	//void PostInitialize(const SceneContext&) override;
	void Update(const SceneContext&) override;


private:
	std::function<void(const PxRaycastBuffer& hit)> m_OnCollision{};


	bool m_IsActive{ true };
	PortalColor m_Color{ PortalColor::Red };

	ParticleEmitterComponent* m_pParticleEmitter = nullptr;
	RigidBodyComponent* m_pRigidBody = nullptr;

	class SpherePrefab* m_pSphere = nullptr;

	XMFLOAT3 m_Direction{};
	const float m_Speed = 100.f;  // Units per second
	const float m_LifeTime = 5.f;

	void HandleCollision(const PxRaycastBuffer& hit);
};

