#include "stdafx.h"
#include "PortalGun.h"
#include <Materials/Shadow/DiffuseMaterial_Shadow.h>

#include "Prefabs/Game/PortalBullet.h"
#include "Prefabs/Game/Portal.h"

PortalGun::PortalGun()
{
}

void PortalGun::Shoot(PortalColor color)
{
	switch(color)
	{
		case PortalColor::Red:
			m_pSoundSystem->playSound(m_pShootRedSound, 0, false, &m_pSoundChannel);
			break;
		case PortalColor::Blue:
			m_pSoundSystem->playSound(m_pShootBlueSound, 0, false, &m_pSoundChannel);
			break;
		default:
			break;
	}

	// Get direction from rotation
	auto rotation = m_pGunGameObject->GetTransform()->GetWorldRotation();
	auto direction = DirectX::XMVector3Rotate(DirectX::XMVectorSet(0, 0, 1, 0), XMLoadFloat4(&rotation));

	auto pBullet = new PortalBullet(color);
	pBullet->SetDirection(direction);

	SceneManager::Get()->GetActiveScene()->AddChild(pBullet);
	pBullet->GetTransform()->Translate(GetTransform()->GetWorldPosition());

	pBullet->SetOnCollision([this, color](const PxRaycastBuffer& hit)
	{
		HandleBulletCollision(hit, color);
	});
}

void PortalGun::Initialize(const SceneContext&)
{

	// Create material
	const auto pMaterial = MaterialManager::Get()->CreateMaterial<DiffuseMaterial_Shadow>();
	pMaterial->SetDiffuseTexture(L"Textures/v_portalgun.png");


	// Create object
	m_pGunGameObject = AddChild(new GameObject());
	auto pModelComponent{ new ModelComponent(L"Meshes/PortalGun.ovm") };
	pModelComponent->SetMaterial(pMaterial);
	m_pGunGameObject->AddComponent(pModelComponent);
	//m_pGunGameObject->GetTransform()->Rotate(90.0f, 180.f , 0.f);
	m_pGunGameObject->GetTransform()->Scale(0.04f);
	//pGun->GetTransform()->Translate(0.0f, -0.f, 0.0f);

	// Init Sounds
	m_pSoundSystem = SoundManager::Get()->GetSystem();
	auto result = m_pSoundSystem->getChannel(1, &m_pSoundChannel);
	result = m_pSoundSystem->createSound("Resources/Audio/PortalgunShootBlue.wav", FMOD_DEFAULT, nullptr, &m_pShootBlueSound);
	result = m_pSoundSystem->createSound("Resources/Audio/PortalgunShootRed.wav", FMOD_DEFAULT, nullptr, &m_pShootRedSound);
	result = m_pSoundSystem->createSound("Resources/Audio/SpawnPortal.wav", FMOD_DEFAULT, nullptr, &m_pSpawnPortalSound);
	result = m_pSoundSystem->createSound("Resources/Audio/FailedSpawnPortal.wav", FMOD_DEFAULT, nullptr, &m_pFailedSpawnPortalSound);
	SoundManager::CheckResult(result);

}

void PortalGun::Update(const SceneContext&)
{

}

void PortalGun::HandleBulletCollision(const PxRaycastBuffer& hit, PortalColor color)
{		
	// Get info from the actor
	auto* pActor{ reinterpret_cast<BaseComponent*>(hit.block.actor->userData) };
	auto* pObject{ pActor->GetGameObject() };

	if(pObject->GetTag() == L"CanSpawnPortal" )
	{
		// Get position from hit
		XMFLOAT3 hitPos{ PhysxHelper::ToXMFLOAT3(hit.block.position) };

		// Get normal from hit
		XMFLOAT3 hitNormal{ PhysxHelper::ToXMFLOAT3(hit.block.normal) };

		if(Portal::CanSpawnPortal(hitPos, hitNormal))
		{
			// Check if enough space to spawn portal (using raycasts)		
			SpawnPortal(hitPos, hitNormal, color);
			return;
		}
	}

	// Play failed sound
	m_pSoundSystem->playSound(m_pFailedSpawnPortalSound, 0, false, &m_pSoundChannel);
}

void PortalGun::SpawnPortal(const XMFLOAT3& position, const XMFLOAT3& forward, PortalColor color)
{
	m_pSoundSystem->playSound(m_pSpawnPortalSound, 0, false, &m_pSoundChannel);


	auto pPortal = new Portal(color);
	SceneManager::Get()->GetActiveScene()->AddChild(pPortal);
	pPortal->GetTransform()->Translate(position);

	XMFLOAT3 rotation = MathHelper::RotationFromDirection(forward);
	rotation.y = XMConvertToDegrees(rotation.y);
	pPortal->GetTransform()->Rotate(0, rotation.y, 0);
}
