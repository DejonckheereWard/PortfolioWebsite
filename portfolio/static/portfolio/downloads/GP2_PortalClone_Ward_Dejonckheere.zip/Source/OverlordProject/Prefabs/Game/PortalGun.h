#pragma once
#include "Prefabs/Game/Portal.h"

// Also manages spawning of portals

class PortalGun final: public GameObject
{
public:
	PortalGun();
	~PortalGun() override = default;
	PortalGun(const PortalGun& other) = delete;
	PortalGun(PortalGun&& other) noexcept = delete;
	PortalGun& operator=(const PortalGun& other) = delete;
	PortalGun& operator=(PortalGun&& other) noexcept = delete;

	void Shoot(PortalColor color);

protected:
	void Initialize(const SceneContext&) override;
	//void PostInitialize(const SceneContext&) override;
	void Update(const SceneContext&) override;

private:
	FMOD::System* m_pSoundSystem{};
	GameObject* m_pGunGameObject{};
	
	class PortalBulletManager* m_pPortalBulletManager{};

	FMOD::Channel* m_pSoundChannel{};
	FMOD::Sound* m_pShootRedSound{};
	FMOD::Sound* m_pShootBlueSound{};
	FMOD::Sound* m_pSpawnPortalSound{};
	FMOD::Sound* m_pFailedSpawnPortalSound{};

	void HandleBulletCollision(const PxRaycastBuffer& hit, PortalColor color);
	void SpawnPortal(const XMFLOAT3& position, const XMFLOAT3& forward, PortalColor color);
};
