#include "stdafx.h"
#include "ModelAnimator.h"

ModelAnimator::ModelAnimator(MeshFilter* pMeshFilter):
	m_pMeshFilter{ pMeshFilter }
{
	SetAnimation(0);
}

void ModelAnimator::Update(const SceneContext& sceneContext)
{

	//We only update the transforms if the animation is running and the clip is set
	if(m_IsPlaying && m_ClipSet)
	{
		float passedTicks = sceneContext.pGameTime->GetElapsed() * m_CurrentClip.ticksPerSecond * m_AnimationSpeed;
		passedTicks = fmod(passedTicks, m_CurrentClip.duration);  // Wraps around if passedTicks is bigger than the duration

		if(m_Reversed)
		{
			m_TickCount -= passedTicks;
			if(m_TickCount < 0)
				m_TickCount += m_CurrentClip.duration;
		}
		else
		{
			m_TickCount += passedTicks;
			if(m_TickCount > m_CurrentClip.duration)
				m_TickCount -= m_CurrentClip.duration;
		}

		//Find the enclosing keys
		AnimationKey keyA, keyB;
		for(auto& key : m_CurrentClip.keys)
		{
			if(key.tick > m_TickCount)
			{
				keyB = key;
				break;
			}
			keyA = key;

		}

		//Interpolate between keys
		// Blendfactor of 1 = full keyA, 0 = full keyB, 0.5 = 50% keyA, 50% keyB
		float blendFactor{ (m_TickCount - keyA.tick) / (keyB.tick - keyA.tick) };
		const size_t nrOfBones = keyA.boneTransforms.size();
		
		m_Transforms.clear();
		m_Transforms.resize(nrOfBones);

		for(size_t boneIdx{}; boneIdx < nrOfBones; ++boneIdx)
		{
			const auto& transformA{ keyA.boneTransforms[boneIdx] };
			const auto& transformB{ keyB.boneTransforms[boneIdx] };

			XMVECTOR translationA{}, rotationA{}, scaleA{};
			XMMatrixDecompose(&scaleA, &rotationA, &translationA, XMLoadFloat4x4(&transformA));

			XMVECTOR translationB{}, rotationB{}, scaleB{};
			XMMatrixDecompose(&scaleB, &rotationB, &translationB, XMLoadFloat4x4(&transformB));

			XMVECTOR newTranslation{ XMVectorLerp(translationA, translationB, blendFactor) };
			XMVECTOR newScale{ XMVectorLerp(scaleA, scaleB, blendFactor) };
			XMVECTOR newRotation{ XMQuaternionSlerp(rotationA, rotationB, blendFactor) };

			// Create new matrix using the new scale rotation and transform
			XMMATRIX newTransform{
				XMMatrixTransformation(
					FXMVECTOR{},
					FXMVECTOR{},
					newScale,
					FXMVECTOR{},
					newRotation, 
					newTranslation
				) 
			};

		 	XMStoreFloat4x4(&m_Transforms[boneIdx], newTransform);
		}
	}
}

void ModelAnimator::SetAnimation(const std::wstring& clipName)
{
	m_ClipSet = false;
	for(const AnimationClip& clip : m_pMeshFilter->m_AnimationClips)
	{
		if(clip.name == clipName)
		{
			SetAnimation(clip);
			return;
		}
		else
		{
			Reset();
			Logger::LogWarning(L"ModelAnimator::SetAnimation(const std::wstring& clipName) > AnimationClip with name: " + clipName + L" not found!");
		}
	}
}

void ModelAnimator::SetAnimation(UINT clipNumber)
{
	//Set m_ClipSet to false
	m_ClipSet = false;
	//Check if clipNumber is smaller than the actual m_AnimationClips vector size
	if(clipNumber >= m_pMeshFilter->m_AnimationClips.size())
	{
		Reset();
		Logger::LogWarning(L"ModelAnimator::SetAnimation(UINT clipNumber) > AnimationClip with number: " + std::to_wstring(clipNumber) + L" not found!");
	}
	else
	{
		const AnimationClip& clip = m_pMeshFilter->m_AnimationClips[clipNumber];
		SetAnimation(clip);
	}
}

void ModelAnimator::SetAnimation(const AnimationClip& clip)
{
	m_ClipSet = true;
	m_CurrentClip = clip;
	Reset(false);
}

void ModelAnimator::Reset(bool pause)
{
	if(pause)
		m_IsPlaying = false;

	m_TickCount = 0;
	m_AnimationSpeed = 1.0f;

	if(m_ClipSet)
	{
		const auto& boneTransforms = m_CurrentClip.keys[0].boneTransforms;
		m_Transforms.clear();
		m_Transforms.assign(begin(boneTransforms), end(boneTransforms));  // Copy vector into other vector
	}
	else
	{
		XMFLOAT4X4 identityMatrix{};
		XMStoreFloat4x4(&identityMatrix, XMMatrixIdentity());

		m_Transforms.assign(m_pMeshFilter->m_BoneCount, identityMatrix);
	}
}
