#include "stdafx.h"
#include "SpriteFont.h"

SpriteFont::SpriteFont(const SpriteFontDesc& fontDesc):
	m_FontDesc(fontDesc){}
