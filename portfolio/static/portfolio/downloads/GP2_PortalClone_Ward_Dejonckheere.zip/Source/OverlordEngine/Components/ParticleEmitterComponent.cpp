#include "stdafx.h"
#include "ParticleEmitterComponent.h"
#include "Misc/ParticleMaterial.h"

ParticleMaterial* ParticleEmitterComponent::m_pParticleMaterial{};

ParticleEmitterComponent::ParticleEmitterComponent(const std::wstring& assetFile, const ParticleEmitterSettings& emitterSettings, UINT particleCount):
	m_ParticlesArray(new Particle[particleCount]),
	m_ParticleCount(particleCount), //How big is our particle buffer?
	m_MaxParticles(particleCount), //How many particles to draw (max == particleCount)
	m_AssetFile(assetFile),
	m_EmitterSettings(emitterSettings)
{
	m_enablePostDraw = true; //This enables the PostDraw function for the component
}

ParticleEmitterComponent::~ParticleEmitterComponent()
{
	delete m_ParticlesArray;

	SafeRelease(m_pVertexBuffer);
}

void ParticleEmitterComponent::Initialize(const SceneContext& sceneContext)
{
	// Only create material once (static variable)
	if(not m_pParticleMaterial)
		m_pParticleMaterial = MaterialManager::Get()->CreateMaterial<ParticleMaterial>();

	CreateVertexBuffer(sceneContext);

	m_pParticleTexture = ContentManager::Load<TextureData>(m_AssetFile);
}

void ParticleEmitterComponent::CreateVertexBuffer(const SceneContext& scenecontext)
{
	SafeRelease(m_pVertexBuffer);

	//Create Vertexbuffer
	D3D11_BUFFER_DESC buffDesc{};
	buffDesc.Usage = D3D11_USAGE_DYNAMIC;
	buffDesc.ByteWidth = m_ParticleCount * sizeof(VertexParticle);
	buffDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	buffDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	buffDesc.MiscFlags = 0;

	// 
	HANDLE_ERROR(scenecontext.d3dContext.pDevice->CreateBuffer(&buffDesc, nullptr, &m_pVertexBuffer));
}

void ParticleEmitterComponent::Update(const SceneContext& sceneContext)
{
	const float elapsedTime{ sceneContext.pGameTime->GetElapsed() };
	const float particleInterval{ (m_EmitterSettings.minEnergy + m_EmitterSettings.maxEnergy) / m_ParticleCount };
	m_LastParticleSpawn += elapsedTime;
	m_ActiveParticles = 0;

	D3D11_MAPPED_SUBRESOURCE subResource{};
	subResource.pData = m_ParticlesArray;

	sceneContext.d3dContext.pDeviceContext->Map(m_pVertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &subResource);

	VertexParticle* pVertexParticleBuffer{ static_cast<VertexParticle*>(subResource.pData) };

	for(size_t particleIdx{ 0 }; particleIdx < m_ParticleCount; particleIdx++)
	{
		Particle& particle = m_ParticlesArray[particleIdx];

		if(particle.isActive)
		{
			UpdateParticle(particle, elapsedTime);
		}

		// Not if else, because update particle can set isActive to false, and then we can immediately respawn one
		if(not particle.isActive)
		{
			if(m_LastParticleSpawn >= particleInterval)
			{
				SpawnParticle(particle);
				m_LastParticleSpawn = 0.0f;
			}
		}

		// IF its still active after all this, add it to the buffer
		if(particle.isActive)
		{
			pVertexParticleBuffer[m_ActiveParticles] = particle.vertexInfo;
			m_ActiveParticles++;
		}


	}

	sceneContext.d3dContext.pDeviceContext->Unmap(m_pVertexBuffer, 0);

}

void ParticleEmitterComponent::UpdateParticle(Particle& p, float elapsedTime) const
{
	if(not p.isActive)
		return;

	// Update energy
	p.currentEnergy -= elapsedTime;
	if(p.currentEnergy < 0.0f)
	{
		p.isActive = false;
		return;
	}

	// Get position, Get Velocity * Elapsed time, add them together and store them in the vertex position;
	XMStoreFloat3(&p.vertexInfo.Position,
		XMLoadFloat3(&p.vertexInfo.Position) + (XMLoadFloat3(&m_EmitterSettings.velocity) * elapsedTime));

	const float lifePercent{ p.currentEnergy / p.totalEnergy };
	const float adjustDelayConstant{ 2.0f };

	// Set color and transparency;
	//p.vertexInfo.Color = m_EmitterSettings.color;
	p.vertexInfo.Color.w = m_EmitterSettings.color.w * (lifePercent * adjustDelayConstant);

	// Set size

	p.vertexInfo.Size = std::lerp(p.initialSize, p.initialSize * p.sizeChange, 1.0f - lifePercent);
}

void ParticleEmitterComponent::SpawnParticle(Particle& p)
{
	if(not m_IsActive)
		return;

	using MathHelper::randF;
	p.isActive = true;

	// Set the random energy
	p.totalEnergy = randF(m_EmitterSettings.minEnergy, m_EmitterSettings.maxEnergy);
	p.currentEnergy = p.totalEnergy;  // Set both to the same random value;

	// Set the random position
	XMVECTOR unitVector{ 1.0, 0.0f, 0.0f };
	XMMATRIX randomRotation{ XMMatrixRotationRollPitchYaw(randF(-XM_PI, XM_PI), randF(-XM_PI, XM_PI), randF(-XM_PI, XM_PI)) };
	XMVECTOR randomDirection{ XMVector3TransformNormal(unitVector, randomRotation) };

	const float distance{ randF(m_EmitterSettings.minEmitterRadius, m_EmitterSettings.maxEmitterRadius) };
	XMVECTOR randomPosition{ XMLoadFloat3(&GetTransform()->GetWorldPosition()) + randomDirection * distance };

	XMStoreFloat3(&p.vertexInfo.Position, randomPosition);

	// Set the random size
	p.initialSize = randF(m_EmitterSettings.minSize, m_EmitterSettings.maxSize);
	p.vertexInfo.Size = p.initialSize;

	p.sizeChange = randF(m_EmitterSettings.minScale, m_EmitterSettings.maxScale);

	// Set random rotation
	p.vertexInfo.Rotation = randF(-XM_PI, XM_PI);

	// Set the color
	p.vertexInfo.Color = m_EmitterSettings.color;
}

void ParticleEmitterComponent::PostDraw(const SceneContext& sceneContext)
{
	m_pParticleMaterial->SetVariable_Matrix(L"gWorldViewProj", sceneContext.pCamera->GetViewProjection());
	m_pParticleMaterial->SetVariable_Matrix(L"gViewInverse", sceneContext.pCamera->GetViewInverse());
	m_pParticleMaterial->SetVariable_Texture(L"gParticleTexture", m_pParticleTexture);


	auto& materialTechinque{ m_pParticleMaterial->GetTechniqueContext() };
	auto& deviceContext{ sceneContext.d3dContext.pDeviceContext };
	deviceContext->IASetInputLayout(materialTechinque.pInputLayout);
	deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY::D3D11_PRIMITIVE_TOPOLOGY_POINTLIST);

	UINT offset{ 0 };
	constexpr UINT stride = sizeof(VertexParticle);
	deviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);


	D3DX11_TECHNIQUE_DESC techDesc{};
	materialTechinque.pTechnique->GetDesc(&techDesc);
	for(UINT p = 0; p < techDesc.Passes; ++p)
	{
		materialTechinque.pTechnique->GetPassByIndex(p)->Apply(0, deviceContext);
		deviceContext->Draw(static_cast<UINT>(m_ActiveParticles), 0);
	}
}

void ParticleEmitterComponent::DrawImGui()
{
	if(ImGui::CollapsingHeader("Particle System"))
	{
		ImGui::SliderUInt("Count", &m_ParticleCount, 0, m_MaxParticles);
		ImGui::InputFloatRange("Energy Bounds", &m_EmitterSettings.minEnergy, &m_EmitterSettings.maxEnergy);
		ImGui::InputFloatRange("Size Bounds", &m_EmitterSettings.minSize, &m_EmitterSettings.maxSize);
		ImGui::InputFloatRange("Scale Bounds", &m_EmitterSettings.minScale, &m_EmitterSettings.maxScale);
		ImGui::InputFloatRange("Radius Bounds", &m_EmitterSettings.minEmitterRadius, &m_EmitterSettings.maxEmitterRadius);
		ImGui::InputFloat3("Velocity", &m_EmitterSettings.velocity.x);
		ImGui::ColorEdit4("Color", &m_EmitterSettings.color.x, ImGuiColorEditFlags_NoInputs);
	}
}

void ParticleEmitterComponent::Disable()
{
	m_IsActive = false;
}

void ParticleEmitterComponent::Enable()
{
	m_IsActive = true;
}
